<?php
/** Changements de statut (formulaires POST ou appels JSON du mode trajet). */
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';

$isJson = str_contains((string)($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json');
require_admin($isJson);
$in = $isJson ? (json_decode((string)file_get_contents('php://input'), true) ?: []) : $_POST;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_check($isJson ? null : ($in['csrf'] ?? ''))) {
    $isJson ? json_out(['error' => 'csrf'], 403) : redirect('admin/');
}
$iv = get_iv((int)($in['id'] ?? 0));
if (!$iv) {
    $isJson ? json_out(['error' => 'notfound'], 404) : redirect('admin/');
}
$id = (int)$iv['id'];
$now = time();
$action = (string)($in['action'] ?? '');
$msg = '';

switch ($action) {
    case 'reminder_sent':
    case 'reminder_unsent':
        $rule = (string)($in['rule'] ?? '');
        $sched = (int)($in['sched'] ?? 0);
        if (!in_array($rule, array_column(reminder_defaults(), 'id'), true) || $sched <= 0) json_out(['error' => 'rule'], 400);
        if ($action === 'reminder_sent') reminder_mark($id, $rule, $sched, (string)($in['via'] ?? 'sms'));
        else reminder_unmark($id, $rule, $sched);
        $rem = array_values(array_filter(iv_reminders(get_iv($id)), fn($r) => $r['rule'] === $rule))[0] ?? null;
        json_out(['ok' => true, 'state' => $rem['state'] ?? null, 'label' => $rem ? reminder_state_label($rem)[1] : '']);
    case 'reminders_off':
    case 'reminders_on':
        update_iv($id, ['reminders_off' => $action === 'reminders_off' ? 1 : 0]);
        $msg = $action === 'reminders_off' ? 'Rappels SMS désactivés pour ce client.' : 'Rappels SMS réactivés pour ce client.';
        break;
    case 'depart':
        $lat = isset($in['lat']) && is_numeric($in['lat']) ? (float)$in['lat'] : null;
        $lon = isset($in['lon']) && is_numeric($in['lon']) ? (float)$in['lon'] : null;
        $iv = start_trip($iv, $lat, $lon);
        $msg = 'Trajet démarré : le client voit votre arrivée en direct.';
        break;
    case 'arrived':
        if ($iv['status'] === 'enroute') $iv = mark_arrived($iv);
        else update_iv($id, ['status' => 'arrived', 'arrived_at' => $now]);
        $msg = 'Arrivée enregistrée.';
        break;
    case 'working':
        update_iv($id, ['status' => 'working', 'started_at' => $now, 'arrived_at' => $iv['arrived_at'] ?: $now]);
        $msg = 'Intervention démarrée.';
        break;
    case 'done':
        update_iv($id, ['status' => 'done', 'done_at' => $now, 'eta_at' => null]);
        db()->prepare('DELETE FROM positions WHERE iv_id = ?')->execute([$id]); // on ne garde pas l'historique GPS
        $msg = 'Intervention terminée. Pensez au message de remerciement !';
        break;
    case 'replan':
        update_iv($id, ['status' => 'planned', 'eta_at' => null, 'done_at' => null, 'arrived_at' => null, 'started_at' => null, 'trip_started_at' => null]);
        $msg = 'Intervention remise en « planifiée ».';
        break;
    case 'stop':
        if ($iv['status'] === 'enroute') update_iv($id, ['status' => 'planned', 'eta_at' => null, 'trip_started_at' => null]);
        db()->prepare('DELETE FROM positions WHERE iv_id = ?')->execute([$id]);
        $msg = 'Trajet arrêté, le partage de position est coupé.';
        break;
    case 'cancel':
        update_iv($id, ['status' => 'cancelled', 'eta_at' => null]);
        db()->prepare('DELETE FROM positions WHERE iv_id = ?')->execute([$id]);
        $msg = 'Intervention annulée.';
        break;
    case 'delete':
        db()->prepare('DELETE FROM interventions WHERE id = ?')->execute([$id]);
        if ($isJson) json_out(['ok' => true]);
        flash('Intervention supprimée.');
        redirect('admin/');
    default:
        $isJson ? json_out(['error' => 'action'], 400) : redirect('admin/view.php?id=' . $id);
}

if ($isJson) {
    $iv = get_iv($id);
    json_out(['ok' => true, 'status' => $iv['status'], 'state' => public_state($iv)]);
}
flash($msg);
redirect('admin/view.php?id=' . $id);
