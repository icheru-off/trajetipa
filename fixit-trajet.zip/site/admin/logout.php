<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_check()) logout();
redirect('admin/login.php');
