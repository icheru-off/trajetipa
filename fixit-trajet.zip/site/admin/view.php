<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin();

$iv = get_iv((int)($_GET['id'] ?? 0));
if (!$iv) redirect('admin/');
$link = client_link($iv['token']);
$msgs = build_messages($iv);
$st = $iv['status'];
$ts = (int)$iv['scheduled_at'];
$services = iv_services($iv);

admin_header(iv_title($iv));
?>
<script type="application/json" id="boot"><?= json_encode([
    'token' => $iv['token'],
    'status' => $st,
    'statusUrl' => base_url('api/status.php'),
    'phone' => phone_e164($iv['client_phone']),
    'email' => $iv['client_email'],
], JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>

<div class="pagehead">
  <div>
    <div class="kicker">// <?= h(fr_relative_day($ts)) ?> · <?= h(iv_slot_short($iv)) ?></div>
    <h1><?= h(iv_title($iv)) ?> <?= status_badge($st) ?></h1>
  </div>
  <div class="actions">
    <a class="btn btn-sm" href="<?= h(base_url('admin/edit.php?id=' . $iv['id'])) ?>"><?= icon('edit') ?>Modifier</a>
  </div>
</div>

<div class="layout2">
<div>
  <section class="card">
    <div class="kicker">// lien de suivi client</div>
    <h2>Lien à envoyer au client</h2>
    <div class="linkbox">
      <input type="text" readonly value="<?= h($link) ?>" id="clientLink">
      <button class="btn" type="button" data-copy="#clientLink" title="Copier"><?= icon('copy') ?></button>
    </div>
    <div class="actions" style="margin-top:10px">
      <a class="btn btn-sm" href="<?= h($link) ?>" target="_blank" rel="noopener"><?= icon('eye') ?>Voir la page client</a>
      <button class="btn btn-sm" type="button" data-share="<?= h($link) ?>">Partager…</button>
    </div>
  </section>

  <section class="card" id="tripCard">
    <div class="kicker">// trajet & statut</div>
    <?php if ($st === 'planned'): ?>
      <h2>Prêt à partir ?</h2>
      <p class="muted">Au moment de prendre la route, ouvrez le <b>mode trajet</b> sur votre iPhone : votre position est partagée en direct avec le client jusqu'à votre arrivée.</p>
      <a class="btn btn-primary btn-lg btn-block" href="<?= h(base_url('admin/drive.php?id=' . $iv['id'])) ?>"><?= icon('car') ?>Je pars – mode trajet</a>
      <form method="post" action="<?= h(base_url('admin/action.php')) ?>" style="margin-top:10px">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$iv['id'] ?>"><input type="hidden" name="action" value="depart">
        <button class="btn btn-block btn-sm" type="submit">Démarrer avec l'app OwnTracks (suivi en arrière-plan)</button>
      </form>
    <?php elseif ($st === 'enroute'): ?>
      <h2>En route 🚗</h2>
      <div id="liveEta" class="msg" style="background:var(--blue-bg);border-color:transparent">
        <div class="small muted">Arrivée estimée</div>
        <div style="font:800 34px/1.1 var(--disp)" data-eta-main>Calcul…</div>
        <div class="small muted" data-eta-sub></div>
      </div>
      <div class="actions" style="margin-top:12px">
        <a class="btn btn-primary" href="<?= h(base_url('admin/drive.php?id=' . $iv['id'])) ?>"><?= icon('car') ?>Mode trajet</a>
        <?php action_btn($iv, 'arrived', 'Je suis arrivé', 'btn-ok', 'flag'); ?>
      </div>
    <?php elseif ($st === 'arrived'): ?>
      <h2>Sur place depuis <?= h(fr_time((int)$iv['arrived_at'])) ?></h2>
      <div class="actions"><?php action_btn($iv, 'working', 'Commencer l\'intervention', 'btn-primary', 'tool'); action_btn($iv, 'done', 'Intervention terminée', 'btn-ok', 'check'); ?></div>
    <?php elseif ($st === 'working'): ?>
      <h2>Intervention en cours</h2>
      <div class="actions"><?php action_btn($iv, 'done', 'Intervention terminée', 'btn-ok', 'check'); ?></div>
    <?php elseif ($st === 'done'): ?>
      <h2>Intervention terminée ✅</h2>
      <p class="muted">Le <?= h(fr_date((int)$iv['done_at'])) ?> à <?= h(fr_time((int)$iv['done_at'])) ?>. La page client reste consultable 48 h puis expire.</p>
      <div class="actions"><?php action_btn($iv, 'replan', 'Remettre en « planifiée »', '', 'edit'); ?></div>
    <?php else: ?>
      <h2>Intervention annulée</h2>
      <div class="actions"><?php action_btn($iv, 'replan', 'Réactiver', '', 'edit'); ?></div>
    <?php endif; ?>

    <?php if (in_array($st, ['enroute', 'arrived'], true) && $iv['route_provider']): ?>
      <p class="small muted" style="margin:12px 0 0">
        Calcul : <?= $iv['route_traffic'] ? 'TomTom (trafic temps réel)' : ($iv['route_provider'] === 'osrm' ? 'OSRM / OpenStreetMap + modèle de circulation' : 'estimation à vol d\'oiseau (service d\'itinéraire injoignable)') ?>
        <?php if ($iv['eta_factor']): ?> · coefficient appliqué ×<?= h(number_format((float)$iv['eta_factor'], 2, ',', '')) ?><?php endif; ?>
      </p>
    <?php endif; ?>
  </section>

  <?php $rems = iv_reminders($iv); if ($rems && $st === 'planned'): ?>
  <section class="card" id="rappels">
    <div class="kicker">// avant l'intervention</div>
    <h2>Rappels SMS</h2>
    <?php if (!empty($iv['reminders_off'])): ?>
      <p class="muted small">Rappels désactivés pour ce client.</p>
    <?php else: ?>
      <?php foreach ($rems as $rem) echo reminder_card($iv, $rem); ?>
    <?php endif; ?>
    <form method="post" action="<?= h(base_url('admin/action.php')) ?>" class="actions" style="margin-top:6px">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$iv['id'] ?>">
      <button class="btn btn-sm btn-ghost" name="action" value="<?= empty($iv['reminders_off']) ? 'reminders_off' : 'reminders_on' ?>" type="submit">
        <?= empty($iv['reminders_off']) ? 'Pas de rappel pour ce client' : 'Réactiver les rappels' ?></button>
      <a class="btn btn-sm btn-ghost" href="<?= h(base_url('admin/settings.php#rappels')) ?>">Régler les rappels</a>
    </form>
  </section>
  <?php endif; ?>

  <section class="card">
    <div class="kicker">// messages prêts à envoyer</div>
    <h2>Messages au client</h2>
    <p class="muted small">Vous les envoyez vous-même : SMS, WhatsApp ou e-mail. Le texte reste modifiable avant l'envoi.</p>
    <?php foreach ($msgs as $key => $m): ?>
      <div class="msg" data-msg="<?= h($key) ?>">
        <div class="msg-head"><h3 style="margin:0"><?= h($m['title']) ?></h3><span class="small muted"><?= h($m['hint']) ?></span></div>
        <textarea data-template="<?= h($m['text']) ?>" data-subject="<?= h($m['subject']) ?>"><?= h(str_replace('{eta}', '[heure d\'arrivée]', $m['text'])) ?></textarea>
        <div class="actions">
          <button class="btn btn-sm" type="button" data-act="copy"><?= icon('copy') ?>Copier</button>
          <?php if ($iv['client_phone']): ?>
            <button class="btn btn-sm" type="button" data-act="sms"><?= icon('sms') ?>SMS</button>
            <button class="btn btn-sm" type="button" data-act="wa"><?= icon('wa') ?>WhatsApp</button>
          <?php endif; ?>
          <?php if ($iv['client_email']): ?>
            <button class="btn btn-sm" type="button" data-act="mail"><?= icon('mail') ?>E-mail</button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </section>
</div>

<div>
  <section class="card">
    <div class="kicker">// détails</div>
    <h2>Intervention</h2>
    <dl class="kv">
      <dt>Rendez-vous</dt><dd><?= h(ucfirst(fr_date($ts, true))) ?>, <?= h(iv_slot($iv)) ?></dd>
      <dt>Durée estimée</dt><dd><?= (int)$iv['duration_min'] ?> min</dd>
      <dt>Adresse</dt><dd><?= h($iv['address']) ?><?php if ($iv['address_extra']): ?><br><span class="muted"><?= h($iv['address_extra']) ?></span><?php endif; ?>
        <br><a class="small" href="https://www.google.com/maps/dir/?api=1&amp;destination=<?= h(rawurlencode($iv['lat'] . ',' . $iv['lon'])) ?>" target="_blank" rel="noopener">Itinéraire Google Maps</a> ·
        <a class="small" href="https://waze.com/ul?ll=<?= h(rawurlencode($iv['lat'] . ',' . $iv['lon'])) ?>&amp;navigate=yes" target="_blank" rel="noopener">Waze</a></dd>
      <?php if ($iv['client_phone']): ?><dt>Téléphone</dt><dd><a href="tel:<?= h(phone_e164($iv['client_phone']) ? '+' . phone_e164($iv['client_phone']) : '') ?>"><?= h(phone_display($iv['client_phone'])) ?></a></dd><?php endif; ?>
      <?php if ($iv['client_email']): ?><dt>E-mail</dt><dd><?= h($iv['client_email']) ?></dd><?php endif; ?>
      <?php if ($services): ?><dt>Prestations</dt><dd><?= h(implode(' · ', $services)) ?></dd><?php endif; ?>
      <?php if ($iv['device']): ?><dt>Matériel</dt><dd><?= h($iv['device']) ?></dd><?php endif; ?>
      <?php if ($iv['problem']): ?><dt>Problème</dt><dd><?= nl2br(h($iv['problem'])) ?></dd><?php endif; ?>
      <?php if ($iv['price_note']): ?><dt>Tarif</dt><dd><?= h($iv['price_note']) ?></dd><?php endif; ?>
      <?php if ($iv['notes']): ?><dt>Notes privées</dt><dd><?= nl2br(h($iv['notes'])) ?></dd><?php endif; ?>
      <?php if ($iv['trip_started_at']): ?><dt>Départ</dt><dd><?= h(fr_time((int)$iv['trip_started_at'])) ?></dd><?php endif; ?>
      <?php if ($iv['arrived_at']): ?><dt>Arrivée</dt><dd><?= h(fr_time((int)$iv['arrived_at'])) ?></dd><?php endif; ?>
      <?php if ($iv['done_at']): ?><dt>Fin</dt><dd><?= h(fr_time((int)$iv['done_at'])) ?></dd><?php endif; ?>
    </dl>
  </section>

  <section class="card">
    <h3>Autres actions</h3>
    <div class="actions">
      <?php if (!in_array($st, ['done', 'cancelled'], true)) action_btn($iv, 'cancel', 'Annuler l\'intervention', 'btn-danger', ''); ?>
      <?php action_btn($iv, 'delete', 'Supprimer définitivement', 'btn-danger', '', 'Supprimer définitivement cette intervention ? Le lien client ne fonctionnera plus.'); ?>
    </div>
  </section>
</div>
</div>
<?php
admin_footer(['js/view.js']);

function action_btn(array $iv, string $action, string $label, string $cls = '', string $ic = '', string $confirm = ''): void
{
    ?>
    <form method="post" action="<?= h(base_url('admin/action.php')) ?>" style="display:inline" <?= $confirm ? 'data-confirm="' . h($confirm) . '"' : '' ?>>
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$iv['id'] ?>"><input type="hidden" name="action" value="<?= h($action) ?>">
      <button class="btn <?= h($cls) ?>" type="submit"><?= $ic ? icon($ic) : '' ?><?= h($label) ?></button>
    </form>
    <?php
}
