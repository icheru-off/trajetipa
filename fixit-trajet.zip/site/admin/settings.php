<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin();

$test = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        flash('Session expirée, réessayez.', 'err');
        redirect('admin/settings.php');
    }
    $sec = (string)($_POST['section'] ?? '');
    switch ($sec) {
        case 'profile':
            set_setting('tech_name', trim((string)$_POST['tech_name']) ?: 'Jules');
            set_setting('tech_phone', trim((string)$_POST['tech_phone']));
            $home = trim((string)($_POST['home'] ?? ''));
            set_setting('home_address', $home);
            $lat = $_POST['home_lat'] ?? '';
            $lon = $_POST['home_lon'] ?? '';
            if ($home !== '' && (!is_numeric($lat) || !is_numeric($lon))) {
                $g = geocode_search($home, 1);
                if ($g) { $lat = $g[0]['lat']; $lon = $g[0]['lon']; }
            }
            set_setting('home_lat', $home !== '' && is_numeric($lat) ? (string)$lat : '');
            set_setting('home_lon', $home !== '' && is_numeric($lon) ? (string)$lon : '');
            set_setting('privacy_m', (string)max(0, min(20000, (int)round((float)str_replace(',', '.', (string)($_POST['privacy_m'] ?? '800'))))));
            set_setting('parking_min', (string)max(0, min(15, (int)$_POST['parking_min'])));
            flash('Profil enregistré.');
            break;
        case 'reminders':
            $rules = [];
            foreach (reminder_defaults() as $i => $d) {
                $in = (array)($_POST['r'][$i] ?? []);
                $when = (string)($in['when'] ?? 'd1');
                $rules[] = [
                    'on' => !empty($in['on']),
                    'kind' => $when === 'm' ? 'minutes' : 'days',
                    'days' => $when === 'm' ? 0 : max(0, min(14, (int)substr($when, 1))),
                    'at' => (string)($in['at'] ?? $d['at']),
                    'minutes' => (int)($in['minutes'] ?? $d['minutes']),
                    'text' => mb_substr(str_replace("\r\n", "\n", trim((string)($in['text'] ?? ''))), 0, 900),
                ];
            }
            set_setting('reminder_rules', json_encode($rules, JSON_UNESCAPED_UNICODE));
            flash('Rappels enregistrés.');
            break;
        case 'eta':
            set_setting('tomtom_key', trim((string)$_POST['tomtom_key']));
            $style = (string)($_POST['map_style'] ?? 'positron');
            set_setting('map_style', in_array($style, ['positron', 'liberty', 'bright'], true) ? $style : 'positron');
            if (!empty($_POST['reset_learning'])) {
                set_setting('learn_osrm', '1.10'); set_setting('learn_osrm_n', '0');
                set_setting('learn_tt', '1.0'); set_setting('learn_tt_n', '0');
            }
            flash('Réglages du calcul enregistrés.');
            break;
        case 'keys':
            if (!empty($_POST['regen_app'])) set_setting('app_key', random_token(24));
            if (!empty($_POST['regen_ot'])) set_setting('owntracks_key', random_token(18));
            flash('Nouvelle clé générée : reconfigurez l\'application concernée.');
            break;
        case 'password':
            $cur = (string)($_POST['current'] ?? '');
            $new = (string)($_POST['new'] ?? '');
            if (!password_verify($cur, (string)setting('admin_hash'))) flash('Mot de passe actuel incorrect.', 'err');
            elseif (mb_strlen($new) < 10) flash('Le nouveau mot de passe doit faire au moins 10 caractères.', 'err');
            else {
                set_setting('admin_hash', password_hash($new, PASSWORD_DEFAULT));
                set_setting('auth_epoch', (string)((int)setting('auth_epoch', '1') + 1));
                set_remember_cookie();
                flash('Mot de passe modifié. Les autres appareils sont déconnectés.');
            }
            break;
        case 'test':
            $t0 = microtime(true);
            $g = geocode_search('Mairie, 77130 La Grande-Paroisse', 1);
            $t1 = microtime(true);
            $r = route_osrm(OSRM_PRIMARY, 48.3870, 2.9040, 48.5390, 2.6600);
            $t2 = microtime(true);
            $r2 = route_osrm(OSRM_FALLBACK, 48.3870, 2.9040, 48.5390, 2.6600);
            $t3 = microtime(true);
            $tt = null;
            if (trim((string)setting('tomtom_key', '')) !== '') $tt = route_tomtom(trim((string)setting('tomtom_key')), 48.3870, 2.9040, 48.5390, 2.6600);
            $test = [
                ['Adresses (IGN Géoplateforme)', (bool)$g, $g ? $g[0]['label'] : 'injoignable', $t1 - $t0],
                ['Itinéraire OSRM (principal)', (bool)$r, $r ? round($r['dist_m'] / 1000, 1) . ' km · ' . round($r['raw_s'] / 60) . ' min sans trafic' : 'injoignable', $t2 - $t1],
                ['Itinéraire OSRM FOSSGIS (secours)', (bool)$r2, $r2 ? round($r2['dist_m'] / 1000, 1) . ' km · ' . round($r2['raw_s'] / 60) . ' min sans trafic' : 'injoignable', $t3 - $t2],
            ];
            if ($tt !== null || trim((string)setting('tomtom_key', '')) !== '') {
                $test[] = ['TomTom trafic temps réel', (bool)$tt, $tt ? round($tt['raw_s'] / 60) . ' min avec trafic (dont ' . round($tt['delay_s'] / 60) . ' min de retard)' : 'clé refusée ou quota atteint', 0];
            }
            break;
    }
    if ($sec !== 'test') redirect('admin/settings.php');
}

$appKey = app_key();
$otKey = (string)setting('owntracks_key', '');
if ($otKey === '') { $otKey = random_token(18); set_setting('owntracks_key', $otKey); }
$setupLink = 'fixittrajet://setup?server=' . rawurlencode(rtrim(base_url(), '/')) . '&key=' . rawurlencode($appKey);
$otUrl = base_url('api/owntracks.php') . '?key=' . $otKey;
$appSeen = (int)setting('app_last_seen', 0);
$otSeen = (int)setting('owntracks_last', 0);
$ttCount = setting('tt_month') === date('Y-m') ? (int)setting('tt_count', 0) : 0;

admin_header('Réglages', 'settings');
?>
<div class="wrap-narrow" style="margin:0 auto">
<div class="pagehead"><div><div class="kicker">// réglages</div><h1>Réglages</h1></div></div>

<form class="card" method="post" autocomplete="off">
  <?= csrf_field() ?><input type="hidden" name="section" value="profile">
  <h2>Profil & confidentialité</h2>
  <div class="grid2">
    <label class="field"><span>Prénom affiché aux clients</span><input type="text" name="tech_name" value="<?= h(tech_name()) ?>"></label>
    <label class="field"><span>Téléphone pro</span><input type="tel" name="tech_phone" value="<?= h(tech_phone()) ?>"></label>
  </div>
  <div class="field ac" data-ac data-proxy="<?= h(base_url('api/geocode.php')) ?>"<?php $hl = setting('home_lat', ''); $ho = setting('home_lon', ''); if ($hl !== '' && $ho !== ''): ?> data-near="<?= h($hl . ',' . $ho) ?>"<?php endif; ?>>
    <span style="display:block;font-weight:600;font-size:14px;margin-bottom:6px">Adresse du domicile (point de départ habituel)</span>
    <input type="text" name="home" value="<?= h(setting('home_address', '')) ?>" data-ac-input placeholder="Votre adresse">
    <input type="hidden" name="home_lat" value="<?= h(setting('home_lat', '')) ?>" data-ac-lat>
    <input type="hidden" name="home_lon" value="<?= h(setting('home_lon', '')) ?>" data-ac-lon>
  </div>
  <div class="grid2">
    <div class="field" data-range>
      <span style="display:block;font-weight:600;font-size:14px;margin-bottom:6px">Zone masquée autour du domicile : <b data-range-out></b></span>
      <div class="range-row">
        <input type="range" min="0" max="5000" step="50" value="<?= min(5000, (int)setting('privacy_m', 800)) ?>" aria-label="Rayon de la zone masquée">
        <span class="num"><input type="number" name="privacy_m" min="0" max="20000" step="1" value="<?= (int)setting('privacy_m', 800) ?>" inputmode="numeric"> m</span>
      </div>
      <small>Rayon en mètres (0 = désactivée, jusqu'à 20 000 m). Dans cette zone, le client voit l'heure d'arrivée mais pas votre position : votre adresse reste privée.</small></div>
    <label class="field"><span>Temps pour se garer</span>
      <select name="parking_min">
        <?php foreach ([0, 1, 2, 3, 5] as $m): ?><option value="<?= $m ?>" <?= (int)setting('parking_min', 2) === $m ? 'selected' : '' ?>><?= $m ?> min</option><?php endforeach; ?>
      </select><small>Ajouté à l'heure d'arrivée annoncée.</small></label>
  </div>
  <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>

<form class="card" method="post" id="rappels">
  <?= csrf_field() ?><input type="hidden" name="section" value="reminders">
  <div class="kicker">// avant l'intervention</div>
  <h2>Rappels SMS au client</h2>
  <p class="muted small">Jusqu'à 3 rappels par intervention, par exemple la veille à 18h. Ils s'envoient depuis votre iPhone, avec votre numéro :
    <b>en un geste</b> (notification de l'app FixIT Trajet ou bouton sur le tableau de bord), ou <b>tout seuls</b> avec une automatisation Raccourcis (voir plus bas).
    Les clients sans numéro de mobile sont ignorés ; un rappel peut être désactivé client par client.</p>
  <?php
  $whenOpts = ['d0' => 'Le jour même à…', 'd1' => 'La veille à…', 'd2' => '2 jours avant à…', 'd3' => '3 jours avant à…', 'd7' => 'Une semaine avant à…', 'm' => 'Quelques heures avant le rendez-vous'];
  $minOpts = [30 => '30 min avant', 60 => '1 h avant', 90 => '1 h 30 avant', 120 => '2 h avant', 180 => '3 h avant', 240 => '4 h avant', 360 => '6 h avant', 720 => '12 h avant'];
  foreach (reminder_rules() as $i => $r):
      $w = $r['kind'] === 'minutes' ? 'm' : 'd' . $r['days'];
      if (!isset($whenOpts[$w])) $whenOpts[$w] = $r['days'] . ' jours avant à…'; ?>
    <fieldset class="rule<?= $r['on'] ? '' : ' off' ?>" data-rule-box>
      <legend><label class="switch"><input type="checkbox" name="r[<?= $i ?>][on]" value="1" <?= $r['on'] ? 'checked' : '' ?> data-rule-on><span></span></label> Rappel <?= $i + 1 ?></legend>
      <div class="rule-when">
        <select name="r[<?= $i ?>][when]" data-rule-when aria-label="Moment du rappel">
          <?php foreach ($whenOpts as $k => $l): ?><option value="<?= $k ?>" <?= $w === $k ? 'selected' : '' ?>><?= h($l) ?></option><?php endforeach; ?>
        </select>
        <input type="time" name="r[<?= $i ?>][at]" value="<?= h($r['at']) ?>" step="300" data-rule-at aria-label="Heure d'envoi">
        <select name="r[<?= $i ?>][minutes]" data-rule-min aria-label="Délai avant le rendez-vous">
          <?php foreach ($minOpts as $m => $l): ?><option value="<?= $m ?>" <?= (int)$r['minutes'] === $m ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?>
        </select>
      </div>
      <textarea name="r[<?= $i ?>][text]" rows="6" data-rule-text><?= h($r['text']) ?></textarea>
      <div class="rule-foot"><span class="small muted" data-rule-count></span><button class="btn btn-sm" type="button" data-rule-reset="<?= h(reminder_defaults()[$i]['text']) ?>">Texte d'origine</button></div>
      <div class="rule-preview"><small>Aperçu (client fictif)</small><div data-rule-preview></div></div>
    </fieldset>
  <?php endforeach; ?>
  <details class="vars"><summary>Mots remplacés automatiquement (touchez pour insérer)</summary>
    <div class="chips"><?php foreach (REMINDER_VARS as $k => $l): ?><button type="button" class="chip-btn" data-var="<?= h($k) ?>" title="<?= h($l) ?>"><?= h($k) ?></button><?php endforeach; ?></div>
    <ul class="small muted"><?php foreach (REMINDER_VARS as $k => $l): ?><li><code><?= h($k) ?></code> : <?= h($l) ?></li><?php endforeach; ?></ul>
  </details>
  <script type="application/json" id="remSample"><?= json_encode([
      '{bonjour}' => 'Bonjour Mme Martin', '{nom}' => 'Mme Martin', '{date}' => 'jeudi 20 novembre', '{creneau}' => 'entre 14h00 et 14h30',
      '{heure}' => '14h00', '{adresse}' => '2 Avenue Thiers 77000 Melun', '{lien}' => client_link('exemple'),
      '{technicien}' => tech_name(), '{telephone}' => tech_phone(),
  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
  <button class="btn btn-primary" type="submit">Enregistrer les rappels</button>
</form>

<section class="card" id="rappels-auto">
  <div class="kicker">// facultatif</div>
  <h2>Envoi automatique des rappels (iPhone)</h2>
  <p class="muted small">Sans aucun service payant : une automatisation de l'app <b>Raccourcis</b> (déjà installée sur l'iPhone) demande au site les rappels à envoyer et les envoie
    elle-même par SMS, sans que vous ayez à toucher l'écran. À créer une seule fois :</p>
  <ol class="small steps">
    <li>Raccourcis › onglet <b>Raccourcis</b> › <b>+</b>. Nommez-le « Rappels FixIT ».</li>
    <li>Action <b>Obtenir le contenu de l'URL</b> : URL ci-dessous, Méthode <b>POST</b>, En-têtes : <code>X-App-Key</code> = la clé ci-dessous,
      Corps de requête <b>JSON</b> : <code>action</code> = <code>reminders_due</code>.</li>
    <li>Action <b>Obtenir la valeur du dictionnaire</b> : clé <code>items</code>, puis <b>Répéter avec chaque élément</b>.</li>
    <li>Dans la boucle : <b>Obtenir la valeur du dictionnaire</b> <code>text</code>, puis <b>Envoyer un message</b> (texte = cette valeur, destinataire = valeur <code>phone</code>),
      en <b>désactivant « Afficher lors de l'exécution »</b>.</li>
    <li>Toujours dans la boucle : <b>Obtenir le contenu de l'URL</b> (même URL et en-tête), corps JSON <code>action</code> = <code>reminder_sent</code>, <code>id</code> = valeur <code>id</code>,
      <code>rule</code> = valeur <code>rule</code>, <code>sched</code> = valeur <code>sched</code>.</li>
    <li>Onglet <b>Automatisation</b> › <b>+</b> › <b>Heure de la journée</b> : 18h00, tous les jours, <b>Exécuter immédiatement</b>, raccourci « Rappels FixIT ».
      Ajoutez d'autres horaires si vous utilisez des rappels « quelques heures avant » (par exemple 7h, 9h, 11h, 13h).</li>
  </ol>
  <label class="field"><span>URL</span><div class="linkbox"><input type="text" readonly id="remUrl" value="<?= h(base_url('api/app.php')) ?>"><button class="btn" type="button" data-copy="#remUrl"><?= icon('copy') ?></button></div></label>
  <label class="field"><span>Clé (en-tête X-App-Key)</span><div class="linkbox"><input type="text" readonly id="remKey" value="<?= h($appKey) ?>"><button class="btn" type="button" data-copy="#remKey"><?= icon('copy') ?></button></div></label>
  <p class="small muted">L'automatisation n'envoie que les rappels dont l'heure est passée et qui n'ont pas encore été envoyés : pas de doublon, même si elle tourne plusieurs fois.
    Dernier envoi automatique : <?= ($ra = (int)setting('reminders_auto_seen', 0)) ? h(fr_relative_day($ra) . ' à ' . fr_time($ra)) : 'jamais' ?>.</p>
</section>

<form class="card" method="post">
  <?= csrf_field() ?><input type="hidden" name="section" value="eta">
  <h2>Calcul de l'heure d'arrivée</h2>
  <p class="muted small">Par défaut : itinéraire OSRM (OpenStreetMap, limitations de vitesse) + modèle des heures de pointe en Île-de-France
    + correction en direct selon votre vitesse GPS réelle (bouchons, accidents, ralentissements) + apprentissage de vos trajets. 100 % gratuit, sans clé.</p>
  <dl class="kv" style="margin-bottom:14px">
    <dt>Coefficient appris</dt><dd>×<?= h(number_format(learned_factor(false), 2, ',', '')) ?> <span class="muted small">(<?= (int)setting('learn_osrm_n', 0) ?> trajet(s) mesuré(s))</span></dd>
  </dl>
  <label class="field"><span>Clé TomTom (facultatif – trafic temps réel)</span>
    <input type="text" name="tomtom_key" value="<?= h(setting('tomtom_key', '')) ?>" placeholder="Laisser vide pour rester 100 % OpenStreetMap">
    <small>Compte gratuit sur developer.tomtom.com, sans carte bancaire : 20 000 calculs / mois offerts, soit largement assez pour un technicien.
      Ajoute les bouchons et accidents en temps réel. Utilisation ce mois-ci : <?= $ttCount ?> / <?= TOMTOM_MONTHLY_CAP ?> (au-delà, retour automatique à OSRM).</small></label>
  <label class="field"><span>Style de carte (client)</span>
    <select name="map_style">
      <?php foreach (['positron' => 'Positron – clair et épuré', 'liberty' => 'Liberty – coloré', 'bright' => 'Bright – contrasté'] as $k => $l): ?>
        <option value="<?= $k ?>" <?= setting('map_style', 'positron') === $k ? 'selected' : '' ?>><?= $l ?></option>
      <?php endforeach; ?>
    </select></label>
  <label class="chip" style="display:inline-block;margin-bottom:14px"><input type="checkbox" name="reset_learning" value="1"><span>Réinitialiser l'apprentissage</span></label><br>
  <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>

<section class="card" id="app">
  <div class="kicker">// recommandé</div>
  <h2>Application iPhone « FixIT Trajet »</h2>
  <p class="muted small">Suivi GPS natif : fonctionne écran verrouillé, mesure la vitesse réelle et garde les positions en mémoire dans les zones sans réseau.
    Une fois l'app installée (voir le guide dans le zip), ouvrez cette page <b>sur l'iPhone</b> et touchez le bouton :</p>
  <a class="btn btn-primary btn-block" href="<?= h($setupLink) ?>">Configurer l'app automatiquement</a>
  <p class="small muted" style="margin:12px 0 6px">Ou saisie manuelle dans l'app :</p>
  <label class="field"><span>Adresse du serveur</span><div class="linkbox"><input type="text" readonly id="srv" value="<?= h(rtrim(base_url(), '/')) ?>"><button class="btn" type="button" data-copy="#srv"><?= icon('copy') ?></button></div></label>
  <label class="field"><span>Clé de l'application</span><div class="linkbox"><input type="text" readonly id="akey" value="<?= h($appKey) ?>"><button class="btn" type="button" data-copy="#akey"><?= icon('copy') ?></button></div></label>
  <p class="small muted">Dernière connexion de l'app : <?= $appSeen ? h(fr_relative_day($appSeen) . ' à ' . fr_time($appSeen)) : 'jamais' ?></p>
</section>

<section class="card">
  <h2>Alternative : OwnTracks (App Store, gratuit)</h2>
  <p class="muted small">Si vous ne voulez pas installer l'IPA : installez « OwnTracks » depuis l'App Store, puis dans Réglages › Connexion :
    Mode <b>HTTP</b>, URL ci-dessous, et passez l'app en mode <b>Déplacement (Move)</b> pendant vos trajets. Démarrez le trajet depuis la fiche intervention.</p>
  <div class="linkbox"><input type="text" readonly id="oturl" value="<?= h($otUrl) ?>"><button class="btn" type="button" data-copy="#oturl"><?= icon('copy') ?></button></div>
  <p class="small muted">Dernière position reçue : <?= $otSeen ? h(fr_relative_day($otSeen) . ' à ' . fr_time($otSeen)) : 'jamais' ?></p>
</section>

<form class="card" method="post" data-confirm="Générer une nouvelle clé ? L'ancienne ne fonctionnera plus.">
  <?= csrf_field() ?><input type="hidden" name="section" value="keys">
  <h3>Clés de sécurité</h3>
  <div class="actions">
    <button class="btn btn-sm" name="regen_app" value="1" type="submit">Nouvelle clé app iPhone</button>
    <button class="btn btn-sm" name="regen_ot" value="1" type="submit">Nouvelle clé OwnTracks</button>
  </div>
</form>

<form class="card" method="post">
  <?= csrf_field() ?><input type="hidden" name="section" value="test">
  <h2>Tester les services gratuits</h2>
  <p class="muted small">Vérifie que votre hébergement o2switch joint bien les services d'adresses et d'itinéraire.</p>
  <?php if ($test): ?>
    <ul style="padding-left:0;list-style:none">
      <?php foreach ($test as [$label, $ok, $detail, $dt]): ?>
        <li style="margin-bottom:6px"><?= $ok ? '✅' : '❌' ?> <b><?= h($label) ?></b> — <?= h($detail) ?><?= $dt ? ' <span class="muted small">(' . number_format($dt, 2, ',', '') . ' s)</span>' : '' ?></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
  <button class="btn" type="submit">Lancer le test</button>
</form>

<form class="card" method="post">
  <?= csrf_field() ?><input type="hidden" name="section" value="password">
  <h2>Mot de passe</h2>
  <div class="grid2">
    <label class="field"><span>Actuel</span><input type="password" name="current" required autocomplete="current-password"></label>
    <label class="field"><span>Nouveau (10 car. min.)</span><input type="password" name="new" minlength="10" required autocomplete="new-password"></label>
  </div>
  <button class="btn" type="submit">Changer le mot de passe</button>
</form>
</div>
<?php admin_footer();
