/* FixIT Suivi — fiche intervention : messages + heure d'arrivée en direct */
(function () {
  'use strict';
  var boot = JSON.parse(document.getElementById('boot').textContent);
  var A = window.FixitAdmin;
  var eta = null;

  function clock(ts) { var d = new Date(ts * 1000); return d.getHours() + 'h' + String(d.getMinutes()).padStart(2, '0'); }
  function roundUp5(ts) { return clock(Math.ceil(ts / 300) * 300); }

  // messages : {eta} remplacé par l'heure estimée arrondie aux 5 minutes supérieures
  var boxes = Array.prototype.slice.call(document.querySelectorAll('[data-msg]'));
  boxes.forEach(function (box) {
    var ta = box.querySelector('textarea');
    ta.addEventListener('input', function () { ta.__edited = true; });
    box.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]');
      if (!b) return;
      var text = ta.value, act = b.getAttribute('data-act');
      if (/\[heure d'arrivée\]/.test(text) && act !== 'copy') A.toast("L'heure d'arrivée s'ajoutera dès le départ");
      if (act === 'copy') A.copy(text);
      else if (act === 'sms') A.openSms(boot.phone, text);
      else if (act === 'wa') A.openWhatsApp(boot.phone, text);
      else if (act === 'mail') A.openMail(boot.email, ta.getAttribute('data-subject'), text);
    });
  });
  function refreshMessages() {
    boxes.forEach(function (box) {
      var ta = box.querySelector('textarea');
      if (ta.__edited) return;
      var tpl = ta.getAttribute('data-template');
      ta.value = tpl.replace(/\{eta\}/g, eta ? roundUp5(eta.at) : "[heure d'arrivée]");
    });
  }

  // heure d'arrivée en direct (même source que la page client)
  var main = document.querySelector('[data-eta-main]'), sub = document.querySelector('[data-eta-sub]');
  function poll() {
    fetch(boot.statusUrl + '?k=' + encodeURIComponent(boot.token) + '&v=999999', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (s) {
        if (s.status !== boot.status) { location.reload(); return; }
        eta = s.eta || null;
        refreshMessages();
        if (main) {
          if (eta) {
            var rem = Math.max(0, Math.round((eta.at - s.now) / 60));
            main.textContent = clock(eta.at) + ' · ' + (rem < 1 ? '< 1 min' : rem + ' min');
            sub.textContent = 'Fourchette ' + clock(eta.low) + ' – ' + clock(eta.high) + (eta.jam ? ' · ralentissement détecté' : '') + (eta.traffic ? ' · trafic temps réel' : '');
          } else {
            main.textContent = 'En attente de position…';
            sub.textContent = 'Ouvrez le mode trajet ou l\'app FixIT Trajet sur votre iPhone.';
          }
        }
      })
      .catch(function () {});
  }
  if (boot.status === 'enroute') { poll(); setInterval(poll, 10000); }
})();
