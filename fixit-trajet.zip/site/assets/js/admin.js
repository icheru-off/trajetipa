/* FixIT Suivi — outils communs de l'espace admin */
(function () {
  'use strict';

  function toast(t) {
    var el = document.getElementById('toast');
    if (!el) return;
    el.textContent = t; el.classList.add('on');
    clearTimeout(el.__t); el.__t = setTimeout(function () { el.classList.remove('on'); }, 2200);
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { toast('Copié ✔'); }, fallback);
    }
    fallback();
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
      try { document.execCommand('copy'); toast('Copié ✔'); } catch (e) { toast('Sélectionnez le texte pour le copier'); }
      document.body.removeChild(ta);
    }
    return Promise.resolve();
  }

  function isApple() { return /iPhone|iPad|Macintosh/.test(navigator.userAgent); }

  function openSms(phone, text) {
    if (!phone) { copyText(text); return; }
    // iOS : sms:num&body=…  /  Android : sms:num?body=…
    var sep = isApple() ? '&' : '?';
    location.href = 'sms:+' + phone + sep + 'body=' + encodeURIComponent(text);
  }
  function openWhatsApp(phone, text) {
    window.open('https://wa.me/' + phone + '?text=' + encodeURIComponent(text), '_blank', 'noopener');
  }
  function openMail(email, subject, text) {
    location.href = 'mailto:' + encodeURIComponent(email) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(text);
  }

  // boutons [data-copy]
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy]');
    if (b) {
      var src = document.querySelector(b.getAttribute('data-copy'));
      if (src) copyText(src.value || src.textContent);
      return;
    }
    var sh = e.target.closest('[data-share]');
    if (sh) {
      var url = sh.getAttribute('data-share');
      if (navigator.share) navigator.share({ title: 'Suivi de votre intervention FixIT', url: url }).catch(function () {});
      else copyText(url);
    }
  });

  // confirmation des actions sensibles
  document.addEventListener('submit', function (e) {
    var msg = e.target.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  });

  /* ───── Créneau d'arrivée : boutons « +30 min », etc. ───── */
  Array.prototype.forEach.call(document.querySelectorAll('[data-slot]'), function (box) {
    var a = box.querySelector('[data-slot-start]'), b = box.querySelector('[data-slot-end]');
    var btns = box.querySelectorAll('[data-slot-len]');
    function toMin(v) { var p = (v || '').split(':'); return p.length === 2 ? (+p[0]) * 60 + (+p[1]) : null; }
    function fmt(m) { return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); }
    function mark() {
      var s = toMin(a.value), e = toMin(b.value), len = (s === null) ? -1 : (e === null ? 0 : e - s);
      Array.prototype.forEach.call(btns, function (x) { x.classList.toggle('on', +x.getAttribute('data-slot-len') === len); });
    }
    Array.prototype.forEach.call(btns, function (x) {
      x.addEventListener('click', function () {
        var s = toMin(a.value), len = +x.getAttribute('data-slot-len');
        if (s === null) { a.focus(); return; }
        b.value = len ? fmt(Math.min(s + len, 23 * 60 + 55)) : '';
        mark();
      });
    });
    var last = toMin(a.value);
    a.addEventListener('change', function () {   // décale la fin avec le début pour garder la même durée
      var s = toMin(a.value), e = toMin(b.value);
      if (s !== null && e !== null && last !== null) b.value = fmt(Math.min(Math.max(s + (e - last), s + 5), 23 * 60 + 55));
      last = s; mark();
    });
    b.addEventListener('change', mark);
    mark();
  });

  /* ───── Zone masquée : curseur + saisie en mètres ───── */
  Array.prototype.forEach.call(document.querySelectorAll('[data-range]'), function (box) {
    var r = box.querySelector('input[type=range]'), n = box.querySelector('input[type=number]'), out = box.querySelector('[data-range-out]');
    function show(v) { v = +v || 0; if (out) out.textContent = v === 0 ? 'désactivée' : (v >= 1000 ? (v / 1000).toLocaleString('fr-FR') + ' km' : v + ' m'); }
    r.addEventListener('input', function () { n.value = r.value; show(r.value); });
    n.addEventListener('input', function () { r.value = Math.min(+n.value || 0, +r.max); show(n.value); });
    show(n.value);
  });

  /* ───── Autocomplétion d'adresse (API Géoplateforme IGN, gratuite) ───── */
  var GEO = 'https://data.geopf.fr/geocodage/search';
  // Priorité aux adresses proches (domicile, sinon Melun) : évite qu'une « rue de la Mairie » du Loiret passe devant.
  function search(q, proxy, near) {
    var ll = (near || '48.54,2.66').split(',');
    var url = GEO + '?limit=6&index=address&lat=' + ll[0] + '&lon=' + ll[1] + '&q=' + encodeURIComponent(q);
    return fetch(url, { cache: 'no-store' }).then(function (r) { if (!r.ok) throw 0; return r.json(); })
      .then(function (j) {
        return (j.features || []).map(function (f) {
          return { label: f.properties.label, context: f.properties.context || '', lon: f.geometry.coordinates[0], lat: f.geometry.coordinates[1] };
        });
      })
      .catch(function () {
        if (!proxy) return [];
        return fetch(proxy + '?q=' + encodeURIComponent(q), { credentials: 'same-origin' })
          .then(function (r) { return r.ok ? r.json() : { results: [] }; })
          .then(function (j) { return j.results || []; }).catch(function () { return []; });
      });
  }

  Array.prototype.forEach.call(document.querySelectorAll('[data-ac]'), function (box) {
    var input = box.querySelector('[data-ac-input]');
    var lat = box.querySelector('[data-ac-lat]'), lon = box.querySelector('[data-ac-lon]'), ok = box.querySelector('[data-ac-ok]');
    var proxy = box.getAttribute('data-proxy'), near = box.getAttribute('data-near');
    var list = document.createElement('div'); list.className = 'ac-list hidden'; box.appendChild(list);
    var badge = document.createElement('span'); badge.className = 'ac-ok'; box.appendChild(badge);
    var timer = null, items = [], sel = -1, seq = 0;
    if (lat.value && lon.value) badge.textContent = '✓ Adresse localisée';

    function close() { list.classList.add('hidden'); sel = -1; }
    function pick(it) {
      input.value = it.label; lat.value = it.lat; lon.value = it.lon; if (ok) ok.value = '1';
      badge.textContent = '✓ Adresse localisée'; close();
    }
    function draw() {
      list.innerHTML = '';
      items.forEach(function (it, i) {
        var b = document.createElement('button'); b.type = 'button'; b.className = i === sel ? 'on' : '';
        b.textContent = it.label;
        var sm = document.createElement('small'); sm.textContent = it.context; b.appendChild(sm);
        b.addEventListener('mousedown', function (ev) { ev.preventDefault(); pick(it); });
        list.appendChild(b);
      });
      list.classList.toggle('hidden', !items.length);
    }
    input.addEventListener('input', function () {
      lat.value = ''; lon.value = ''; if (ok) ok.value = '0'; badge.textContent = '';
      clearTimeout(timer);
      var q = input.value.trim();
      if (q.length < 4) { items = []; draw(); return; }
      timer = setTimeout(function () {
        var my = ++seq;
        search(q, proxy, near).then(function (res) { if (my === seq) { items = res; sel = -1; draw(); } });
      }, 250);
    });
    input.addEventListener('keydown', function (e) {
      if (list.classList.contains('hidden')) return;
      if (e.key === 'ArrowDown') { sel = Math.min(items.length - 1, sel + 1); draw(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); }
      else if (e.key === 'Enter' && sel >= 0) { pick(items[sel]); e.preventDefault(); }
      else if (e.key === 'Escape') close();
    });
    input.addEventListener('blur', function () { setTimeout(close, 150); });
  });

  /* ───── Réglages : règles de rappel (affichage, aperçu, mots variables) ───── */
  var sampleEl = document.getElementById('remSample');
  var sample = sampleEl ? JSON.parse(sampleEl.textContent) : {};
  var lastText = null;
  function smsCount(t) {
    var n = t.length;
    return n + ' caractères' + (n > 480 ? ' · message long, pensez à raccourcir' : '');
  }
  Array.prototype.forEach.call(document.querySelectorAll('[data-rule-box]'), function (box) {
    var on = box.querySelector('[data-rule-on]'), when = box.querySelector('[data-rule-when]');
    var at = box.querySelector('[data-rule-at]'), min = box.querySelector('[data-rule-min]');
    var ta = box.querySelector('[data-rule-text]'), pv = box.querySelector('[data-rule-preview]'), cnt = box.querySelector('[data-rule-count]');
    function upd() {
      box.classList.toggle('off', !on.checked);
      var m = when.value === 'm';
      at.hidden = m; min.hidden = !m;
      var days = m ? 0 : +when.value.slice(1);
      var quand = (m || days === 0) ? "aujourd'hui" : (days === 1 ? 'demain' : 'le jeudi 20 novembre');
      var t = ta.value;
      Object.keys(sample).forEach(function (k) { t = t.split(k).join(sample[k]); });
      t = t.split('{quand}').join(quand);
      pv.textContent = t.trim();
      cnt.textContent = smsCount(t.trim());
    }
    [on, when, at, min].forEach(function (el) { el.addEventListener('change', upd); });
    ta.addEventListener('input', upd);
    ta.addEventListener('focus', function () { lastText = ta; });
    box.querySelector('[data-rule-reset]').addEventListener('click', function () {
      if (confirm('Remettre le texte d\'origine de ce rappel ?')) { ta.value = this.getAttribute('data-rule-reset'); upd(); }
    });
    upd();
  });
  Array.prototype.forEach.call(document.querySelectorAll('[data-var]'), function (b) {
    b.addEventListener('click', function () {
      var ta = lastText || document.querySelector('[data-rule-text]');
      if (!ta) return;
      var v = b.getAttribute('data-var'), a = ta.selectionStart || ta.value.length, z = ta.selectionEnd || a;
      ta.value = ta.value.slice(0, a) + v + ta.value.slice(z);
      ta.focus(); ta.setSelectionRange(a + v.length, a + v.length);
      ta.dispatchEvent(new Event('input'));
    });
  });

  /* ───── Rappels à envoyer (tableau de bord, fiche) ───── */
  Array.prototype.forEach.call(document.querySelectorAll('[data-rem]'), function (box) {
    var ta = box.querySelector('textarea'), chip = box.querySelector('[data-rem-state]');
    if (!ta) return;
    function setSent(sent, label) {
      box.classList.toggle('done', sent);
      box.classList.toggle('due', false);
      Array.prototype.forEach.call(box.querySelectorAll('[data-rem-act]'), function (b) {
        b.hidden = sent ? b.getAttribute('data-rem-act') !== 'undo' : b.getAttribute('data-rem-act') === 'undo';
      });
      if (label) { chip.textContent = label; chip.className = 'state ' + (sent ? 'sent' : ''); }
    }
    function post(action, via) {
      return fetch(box.getAttribute('data-url'), {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': box.getAttribute('data-csrf') },
        body: JSON.stringify({ action: action, id: +box.getAttribute('data-iv'), rule: box.getAttribute('data-rule'), sched: +box.getAttribute('data-sched'), via: via || 'sms' })
      }).then(function (r) { return r.json(); }).then(function (j) {
        if (!j.ok) throw 0;
        setSent(j.state === 'sent', j.label);
      }).catch(function () { toast('Connexion impossible, réessayez'); });
    }
    if (box.classList.contains('done')) setSent(true);
    box.addEventListener('click', function (e) {
      var b = e.target.closest('[data-rem-act]');
      if (!b) return;
      var act = b.getAttribute('data-rem-act'), phone = box.getAttribute('data-phone');
      if (act === 'copy') { copyText(ta.value); return; }
      if (act === 'undo') { post('reminder_unsent'); return; }
      if (act === 'mark') { post('reminder_sent', 'manuel'); return; }
      // SMS / WhatsApp : on note le rappel comme envoyé puis on ouvre l'application
      post('reminder_sent', act === 'wa' ? 'whatsapp' : 'sms');
      if (act === 'sms') openSms(phone, ta.value); else openWhatsApp(phone, ta.value);
    });
  });

  window.FixitAdmin = { toast: toast, copy: copyText, openSms: openSms, openWhatsApp: openWhatsApp, openMail: openMail };
})();
