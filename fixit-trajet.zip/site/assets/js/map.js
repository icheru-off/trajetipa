/* FixIT Suivi — carte partagée (page client + mode trajet). MapLibre + OpenFreeMap. */
(function () {
  'use strict';

  var CAR_SVG =
    '<svg viewBox="0 0 64 34" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<path d="M4 22c0-4 2-6 6-7l8-1 6-7c1.5-1.5 3-2 5-2h13c2 0 3.5.8 4.8 2.2L53 14l5 1c3 .6 4 2.5 4 5v4c0 1.7-1.3 3-3 3H7c-1.7 0-3-1.3-3-3z" fill="#1489C4"/>' +
    '<path d="M26 8l-3 6h11V8zM37 8v6h12l-4.5-5c-.6-.6-1.3-1-2.2-1z" fill="#CDEFFC"/>' +
    '<rect x="33.5" y="16" width="7" height="1.6" rx=".8" fill="#0C6D9E"/>' +
    '<path d="M58.5 17.5h2.5v3h-2.5z" fill="#FFD27A"/><path d="M4.5 19h2v3h-2z" fill="#E2685F"/>' +
    '<circle cx="16" cy="27" r="6" fill="#111412"/><circle cx="16" cy="27" r="2.6" fill="#C9CDCB"/>' +
    '<circle cx="49" cy="27" r="6" fill="#111412"/><circle cx="49" cy="27" r="2.6" fill="#C9CDCB"/>' +
    '</svg>';

  var HOME_SVG =
    '<svg viewBox="0 0 44 52" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<path d="M22 51S3 33.5 3 21a19 19 0 0 1 38 0c0 12.5-19 30-19 30z" fill="#111412"/>' +
    '<circle cx="22" cy="21" r="14" fill="#fff"/>' +
    '<path d="M14 21.5l8-7 8 7M16.5 19.5v8h11v-8" fill="none" stroke="#1489C4" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</svg>';

  function carElement(label) {
    var el = document.createElement('div');
    el.className = 'car-marker';
    el.innerHTML = '<div class="pulse"></div><div class="cone"></div><div class="disc">' + CAR_SVG + '</div>' +
      (label ? '<div class="car-label">' + label + '</div>' : '');
    return el;
  }

  function setHeading(el, heading) {
    var cone = el.querySelector('.cone');
    var svg = el.querySelector('.disc svg');
    if (heading === null || heading === undefined || isNaN(heading)) { cone.style.display = 'none'; return; }
    cone.style.display = '';
    cone.style.transform = 'rotate(' + heading + 'deg)';
    // la petite voiture regarde vers la gauche quand on roule vers l'ouest
    svg.style.transform = (heading > 180 && heading < 360) ? 'scaleX(-1)' : 'none';
  }

  function homeElement() {
    var el = document.createElement('div');
    el.className = 'home-marker';
    el.innerHTML = HOME_SVG;
    return el;
  }

  function createMap(container, opts) {
    if (!window.maplibregl) return null;
    try { maplibregl.setWorkerUrl(opts.workerUrl); } catch (e) { /* versions anciennes */ }
    var map = new maplibregl.Map({
      container: container,
      style: opts.styleUrl,
      center: opts.center || [2.85, 48.38],
      zoom: opts.zoom || 11,
      attributionControl: { compact: true },
      dragRotate: false,
      pitchWithRotate: false,
      cooperativeGestures: !!opts.cooperative,
      fadeDuration: 0
    });
    map.touchZoomRotate.disableRotation();
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right');
    map.on('load', function () {
      map.addSource('route', { type: 'geojson', data: lineFeature([]) });
      map.addLayer({ id: 'route-casing', type: 'line', source: 'route',
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: { 'line-color': '#0C6D9E', 'line-width': ['interpolate', ['linear'], ['zoom'], 8, 5, 15, 11], 'line-opacity': .35 } });
      map.addLayer({ id: 'route-line', type: 'line', source: 'route',
        layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: { 'line-color': '#1489C4', 'line-width': ['interpolate', ['linear'], ['zoom'], 8, 3, 15, 7] } });
      map.__ready = true;
      if (map.__pendingRoute) { setRoute(map, map.__pendingRoute); map.__pendingRoute = null; }
    });
    return map;
  }

  function lineFeature(coords) {
    return { type: 'Feature', properties: {}, geometry: { type: 'LineString', coordinates: coords && coords.length > 1 ? coords : [] } };
  }

  function setRoute(map, coords) {
    if (!map) return;
    if (!map.__ready) { map.__pendingRoute = coords; return; }
    var src = map.getSource('route');
    if (src) src.setData(lineFeature(coords));
  }

  /** Déplacement fluide d'un marqueur. */
  function animateTo(marker, lngLat, ms) {
    var from = marker.getLngLat();
    if (!from || (from.lng === 0 && from.lat === 0)) { marker.setLngLat(lngLat); return; }
    var start = performance.now();
    var dLng = lngLat[0] - from.lng, dLat = lngLat[1] - from.lat;
    if (Math.abs(dLng) > .2 || Math.abs(dLat) > .2) { marker.setLngLat(lngLat); return; }
    if (marker.__anim) cancelAnimationFrame(marker.__anim);
    function step(now) {
      var t = Math.min(1, (now - start) / ms);
      var e = t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      marker.setLngLat([from.lng + dLng * e, from.lat + dLat * e]);
      if (t < 1) marker.__anim = requestAnimationFrame(step);
    }
    marker.__anim = requestAnimationFrame(step);
  }

  /** Projette un point sur l'itinéraire. Retourne {i, t, d, pt} (segment, fraction, distance en m, point projeté). */
  function project(coords, lon, lat) {
    if (!coords || coords.length < 2) return null;
    var kx = 111320 * Math.cos(lat * Math.PI / 180), ky = 110540, best = null;
    for (var i = 0; i < coords.length - 1; i++) {
      var ax = (coords[i][0] - lon) * kx, ay = (coords[i][1] - lat) * ky;
      var bx = (coords[i + 1][0] - lon) * kx, by = (coords[i + 1][1] - lat) * ky;
      var dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
      var t = l2 > 0 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / l2)) : 0;
      var d = Math.hypot(ax + t * dx, ay + t * dy);
      if (!best || d < best.d) best = { i: i, t: t, d: d };
    }
    var a = coords[best.i], b = coords[best.i + 1];
    best.pt = [a[0] + (b[0] - a[0]) * best.t, a[1] + (b[1] - a[1]) * best.t];
    return best;
  }

  /** Itinéraire restant : on efface la portion déjà parcourue derrière la voiture. */
  function remaining(coords, lon, lat) {
    var p = project(coords, lon, lat);
    if (!p || p.d > 150) return coords;
    return [[lon, lat], p.pt].concat(coords.slice(p.i + 1));
  }

  function fmtClock(ts) {
    var d = new Date(ts * 1000);
    return d.getHours() + 'h' + String(d.getMinutes()).padStart(2, '0');
  }

  function fmtDuration(sec) {
    var m = Math.max(1, Math.round(sec / 60));
    if (m < 60) return m + ' min';
    var hh = Math.floor(m / 60), mm = m % 60;
    return hh + ' h' + (mm ? ' ' + String(mm).padStart(2, '0') : '');
  }

  function fmtKm(m) {
    if (m < 1000) return Math.round(m / 10) * 10 + ' m';
    return (m / 1000).toFixed(m < 10000 ? 1 : 0).replace('.', ',') + ' km';
  }

  window.FixitMap = {
    createMap: createMap, carElement: carElement, setHeading: setHeading, homeElement: homeElement,
    setRoute: setRoute, animateTo: animateTo, project: project, remaining: remaining, fmtClock: fmtClock, fmtDuration: fmtDuration, fmtKm: fmtKm
  };
})();
