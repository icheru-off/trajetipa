/* FixIT Suivi — mode trajet : partage la position GPS de l'iPhone pendant le trajet. */
(function () {
  'use strict';
  var boot = JSON.parse(document.getElementById('boot').textContent);
  var F = window.FixitMap;
  var $ = function (id) { return document.getElementById(id); };
  var status = boot.status;
  var watchId = null, last = null, lastSent = null, lastSentAt = 0, sending = false, routeV = -1, eta = null;
  var wakeLock = null, hiddenAt = 0, map = null, car = null, carEl = null, follow = true, routeCoords = [];

  /* ───── Interface ───── */
  function showCtl() {
    $('ctlPlanned').classList.toggle('hidden', status !== 'planned');
    $('ctlEnroute').classList.toggle('hidden', status !== 'enroute');
    $('ctlArrived').classList.toggle('hidden', ['arrived', 'working', 'done'].indexOf(status) < 0);
    if (status === 'enroute') info('Position partagée en direct avec le client.');
  }
  function info(t) { $('info').textContent = t; }
  function gps(cls, txt) { var el = $('gps'); el.className = 'd-gps ' + cls; el.querySelector('em').textContent = txt; }
  function banner(t) { var b = $('banner'); if (!t) { b.classList.add('hidden'); return; } b.textContent = t; b.classList.remove('hidden'); }

  function renderEta(s) {
    if (!s) return;
    eta = s.eta || null;
    if (s.eta) {
      var rem = s.eta.at - s.now;
      $('etaClock').textContent = F.fmtClock(s.eta.at);
      $('etaRem').textContent = rem > 60 ? F.fmtDuration(rem) : '< 1 min';
      $('etaDist').textContent = F.fmtKm(s.eta.dist_m || 0);
    }
    if (s.route) { routeCoords = s.route; routeV = s.route_v; }
    if (routeCoords.length) F.setRoute(map, last ? F.remaining(routeCoords, last.lon, last.lat) : routeCoords);
    if (s.speed !== null && s.speed !== undefined && last) last.serverSpeed = s.speed;
  }

  /* ───── Carte ───── */
  function initMap() {
    try {
      map = F.createMap('map', { styleUrl: boot.styleUrl, workerUrl: boot.workerUrl, center: [boot.dest.lon, boot.dest.lat], zoom: 12 });
    } catch (e) { map = null; return; }
    if (!map) return;
    new maplibregl.Marker({ element: F.homeElement(), anchor: 'bottom' }).setLngLat([boot.dest.lon, boot.dest.lat]).addTo(map);
    map.on('dragstart', function (e) { if (e.originalEvent) follow = false; });
    map.on('click', function () { follow = true; centerOn(); });
  }
  function centerOn() {
    if (!map || !last) return;
    var c = [last.lon, last.lat], b = new maplibregl.LngLatBounds(c, c).extend([boot.dest.lon, boot.dest.lat]);
    map.fitBounds(b, { padding: 60, maxZoom: 16, duration: 700 });
  }
  function moveCar(p) {
    if (!map) return;
    var ll = [p.lon, p.lat];
    if (!car) {
      carEl = F.carElement('Moi');
      car = new maplibregl.Marker({ element: carEl, anchor: 'center' }).setLngLat(ll).addTo(map);
      centerOn();
    } else {
      F.animateTo(car, ll, 900);
      if (follow) centerOn();
    }
    F.setHeading(carEl, p.heading);
    if (routeCoords.length) F.setRoute(map, F.remaining(routeCoords, p.lon, p.lat));
  }

  /* ───── Réseau ───── */
  function post(url, body) {
    return fetch(url, {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': boot.csrf },
      body: JSON.stringify(body)
    }).then(function (r) {
      if (r.status === 401) { location.href = boot.viewUrl; throw new Error('auth'); }
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  /* File d'attente hors-ligne : chaque position est gardée (et sauvegardée sur l'iPhone)
     jusqu'à ce que le serveur la reçoive. En zone blanche, tout part en un seul lot au retour du réseau. */
  var QKEY = 'fixit_queue_' + boot.id;
  var queue = loadQueue(), failCount = 0, nextTry = 0, lastQueuedAt = 0;
  function loadQueue() { try { return JSON.parse(localStorage.getItem(QKEY) || '[]') || []; } catch (e) { return []; } }
  function saveQueue() { try { localStorage.setItem(QKEY, JSON.stringify(queue.slice(-400))); } catch (e) {} }
  function enqueue(p) {
    queue.push({ lat: +p.lat.toFixed(6), lon: +p.lon.toFixed(6), acc: p.acc, speed: p.speed, heading: p.heading, ts: p.ts });
    if (queue.length > 400) queue = queue.slice(-400);
    lastQueuedAt = Date.now();
    saveQueue();
  }

  function flush(force) {
    if (sending || status !== 'enroute' || !queue.length) return;
    if (!force && Date.now() < nextTry) return;
    sending = true;
    var batch = queue.slice(0, 120);
    var ctrl = ('AbortController' in window) ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 12000);
    fetch(boot.trackUrl, {
      method: 'POST', credentials: 'same-origin', cache: 'no-store', signal: ctrl ? ctrl.signal : undefined,
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': boot.csrf },
      body: JSON.stringify({ id: boot.id, points: batch, v: routeV })
    }).then(function (r) {
      if (r.status === 401) { location.href = boot.viewUrl; throw new Error('auth'); }
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (s) {
      queue = queue.slice(batch.length); saveQueue();
      failCount = 0; nextTry = 0; lastSentAt = Date.now();
      renderEta(s);
      netState();
      if (s.status !== 'enroute') {
        status = s.status; stopWatch(); showCtl(); queue = []; saveQueue();
        if (s.status === 'arrived') toast('Arrivée détectée automatiquement ✅');
      }
    }).catch(function () {
      failCount++;
      nextTry = Date.now() + Math.min(30000, 2000 * Math.pow(2, failCount - 1));
      netState();
    }).then(function () { clearTimeout(timer); sending = false; });
  }

  function netState() {
    if (status !== 'enroute') return;
    if (failCount) info('Réseau faible : ' + queue.length + ' position(s) en attente, envoi automatique dès le retour du réseau.');
    else info('Position partagée en direct avec le client' + (last && last.speed !== null ? ' · ' + Math.round(last.speed * 3.6) + ' km/h' : '') + '.');
  }

  function distance(a, b) {
    var R = 6371000, toR = Math.PI / 180;
    var dLat = (b.lat - a.lat) * toR, dLon = (b.lon - a.lon) * toR;
    var x = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a.lat * toR) * Math.cos(b.lat * toR) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(x)));
  }

  /* ───── GPS ───── */
  function onPos(pos) {
    var c = pos.coords;
    last = {
      lat: c.latitude, lon: c.longitude, acc: Math.round(c.accuracy || 0),
      speed: (c.speed !== null && c.speed >= 0) ? c.speed : null,
      heading: (c.heading !== null && !isNaN(c.heading) && c.speed > 1) ? c.heading : (last ? last.heading : null),
      ts: Math.round(pos.timestamp / 1000)
    };
    gps(last.acc <= 50 ? 'ok' : 'warn', '± ' + last.acc + ' m');
    moveCar(last);
    if (status !== 'enroute') return;
    var prev = queue.length ? queue[queue.length - 1] : lastSent;
    if (!prev || distance(prev, last) > 15 || Date.now() - lastQueuedAt > 5000) { enqueue(last); lastSent = last; }
    if (Date.now() - lastSentAt > 4000) flush(false);
  }
  function onErr(err) {
    if (err.code === 1) {
      gps('err', 'Refusé');
      banner('Localisation refusée. Sur iPhone : Réglages › Confidentialité › Service de localisation › Safari › « Lorsque l\'app est active », puis rechargez la page.');
    } else {
      gps('warn', 'Recherche…');
    }
  }
  function startWatch() {
    if (!('geolocation' in navigator)) { banner('Ce navigateur ne permet pas la géolocalisation.'); return; }
    if (watchId !== null) return;
    watchId = navigator.geolocation.watchPosition(onPos, onErr, { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 });
    keepAwake();
  }
  function stopWatch() {
    if (watchId !== null) navigator.geolocation.clearWatch(watchId);
    watchId = null;
    if (wakeLock) { try { wakeLock.release(); } catch (e) {} wakeLock = null; }
  }

  // à l'arrêt (bouchon, feu…) l'iPhone n'envoie plus de nouvelles positions : on renvoie la dernière
  // avec l'heure actuelle pour que le serveur constate le ralentissement et recalcule l'arrivée.
  setInterval(function () {
    if (status !== 'enroute') return;
    if (last && Date.now() - lastQueuedAt > 15000) enqueue({ lat: last.lat, lon: last.lon, acc: last.acc, speed: 0, heading: last.heading, ts: Math.round(Date.now() / 1000) });
    flush(false);
  }, 3000);
  window.addEventListener('online', function () { nextTry = 0; flush(true); });

  /* ───── Écran allumé ───── */
  function keepAwake() {
    if (!('wakeLock' in navigator) || document.hidden) return;
    navigator.wakeLock.request('screen').then(function (l) { wakeLock = l; }).catch(function () {});
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { hiddenAt = Date.now(); return; }
    if (status === 'enroute') {
      keepAwake();
      if (hiddenAt && Date.now() - hiddenAt > 20000) {
        banner('Le partage était en pause pendant ' + Math.round((Date.now() - hiddenAt) / 60000 + .4) + ' min (écran verrouillé ou autre app). C\'est reparti.');
        setTimeout(function () { banner(''); }, 9000);
      }
      flush(true);
    }
  });

  /* ───── Boutons ───── */
  $('btnStart').addEventListener('click', function () {
    var btn = this;
    btn.disabled = true; btn.textContent = 'Localisation…';
    if (!('geolocation' in navigator)) { banner('Géolocalisation indisponible.'); btn.disabled = false; return; }
    navigator.geolocation.getCurrentPosition(function (pos) {
      var c = pos.coords;
      post(boot.actionUrl, { id: boot.id, action: 'depart', lat: c.latitude, lon: c.longitude }).then(function (r) {
        status = r.status; showCtl(); toast('Trajet démarré : le client vous voit arriver');
        queue = []; saveQueue(); onPos(pos); startWatch(); flush(true);
      }).catch(function () { btn.disabled = false; btn.textContent = '🚗 Je pars'; banner('Impossible de démarrer le trajet (réseau). Réessayez.'); });
    }, function (err) {
      btn.disabled = false; btn.textContent = '🚗 Je pars'; onErr(err);
      if (err.code !== 1) banner('Position introuvable pour l\'instant. Réessayez à l\'extérieur.');
    }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 });
  });

  $('btnArrived').addEventListener('click', function () {
    post(boot.actionUrl, { id: boot.id, action: 'arrived' }).then(function (r) { status = r.status; stopWatch(); showCtl(); }).catch(function () { toast('Réseau indisponible, réessayez'); });
  });

  $('btnStop').addEventListener('click', function () {
    if (!confirm('Arrêter le trajet ? Le client ne verra plus votre position.')) return;
    post(boot.actionUrl, { id: boot.id, action: 'stop' }).then(function (r) { status = r.status; stopWatch(); showCtl(); info('Trajet arrêté.'); }).catch(function () {});
  });

  $('btnMsg').addEventListener('click', function () {
    var when = eta ? roundUp5(eta.at) : 'dès que possible';
    var text = boot.enrouteMsg.replace(/\{eta\}/g, when);
    if (window.FixitAdmin) window.FixitAdmin.openSms(boot.phone, text);
  });
  function roundUp5(ts) { return F.fmtClock(Math.ceil(ts / 300) * 300); }
  function toast(t) { if (window.FixitAdmin) window.FixitAdmin.toast(t); }

  initMap();
  showCtl();
  if (status === 'enroute') { startWatch(); }
})();
