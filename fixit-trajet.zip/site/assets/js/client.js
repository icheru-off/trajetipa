/* FixIT Suivi — page client */
(function () {
  'use strict';
  var boot = JSON.parse(document.getElementById('boot').textContent);
  var F = window.FixitMap;
  var $ = function (id) { return document.getElementById(id); };
  var state = boot.state;
  var routeV = -1;
  var offset = 0;            // décalage horloge serveur - appareil (s)
  var map = null, car = null, carEl = null, home = null;
  var follow = true, fitted = false, pollTimer = null, failures = 0, lastOk = Date.now(), routeCoords = [];
  var ORDER = ['planned', 'enroute', 'arrived', 'working', 'done'];
  var DAYS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  var MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

  function now() { return Date.now() / 1000 + offset; }

  function dayLabel(ts) {
    var d = new Date(ts * 1000), t = new Date(now() * 1000);
    var tomorrow = new Date(t); tomorrow.setDate(t.getDate() + 1);
    if (d.toDateString() === t.toDateString()) return "aujourd'hui";
    if (d.toDateString() === tomorrow.toDateString()) return 'demain';
    return DAYS[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()];
  }

  function setText(id, html) { var el = $(id); if (el.innerHTML !== html) el.innerHTML = html; }

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ───── Affichage ───── */
  function render(skipMap) {
    var s = state, st = s.expired ? 'done' : s.status, tech = esc(boot.tech);
    $('hero').setAttribute('data-status', st);
    $('liveTag').classList.toggle('on', st === 'enroute');
    $('liveTag').lastChild.nodeValue = st === 'enroute' ? 'En direct' : 'Suivi';

    var kicker = '', title = '', big = '', sub = '', note = '';
    if (s.expired) {
      kicker = 'Suivi terminé'; title = 'Ce suivi d\'intervention est terminé.'; sub = 'Merci pour votre confiance !';
    } else if (st === 'planned') {
      kicker = 'Rendez-vous confirmé';
      if (s.slot_end) {
        title = tech + ' arrivera chez vous entre';
        big = F.fmtClock(s.scheduled_at) + '<small> et </small>' + F.fmtClock(s.slot_end);
      } else {
        title = tech + ' passera chez vous';
        big = F.fmtClock(s.scheduled_at);
      }
      sub = dayLabel(s.scheduled_at);
      note = 'Le suivi en direct s\'activera automatiquement dès que votre technicien prendra la route.';
    } else if (st === 'enroute') {
      kicker = 'En route vers chez vous';
      var e = s.eta;
      if (!e) {
        title = 'Votre technicien est parti';
        sub = 'Calcul de l\'heure d\'arrivée…';
      } else {
        var rem = e.at - now();
        if (rem <= 90) {
          title = 'Votre technicien arrive';
          sub = rem > 0 ? 'dans un instant 👋' : 'd\'une minute à l\'autre 👋';
        } else {
          title = 'Votre technicien arrive dans';
          var m = Math.round(rem / 60);
          big = m < 60 ? m + '<small>min</small>' : Math.floor(m / 60) + '<small>h</small>' + String(m % 60).padStart(2, '0');
          sub = 'Arrivée estimée vers ' + F.fmtClock(e.at);
        }
        var range = (e.high - e.low) >= 240 ? ' (entre ' + F.fmtClock(e.low) + ' et ' + F.fmtClock(e.high) + ')' : '';
        note = 'Heure estimée' + range + ', calculée selon l\'itinéraire, les limitations de vitesse et '
          + (e.traffic ? 'le trafic en temps réel' : 'la circulation constatée pendant le trajet')
          + '. Elle peut varier.';
      }
    } else if (st === 'arrived') {
      kicker = 'C\'est l\'heure';
      title = 'Votre technicien est arrivé 👋';
      sub = tech + ' est devant chez vous.';
    } else if (st === 'working') {
      kicker = 'Intervention en cours';
      title = tech + ' s\'occupe de votre ordinateur.';
      sub = 'Prévoyez vos identifiants si besoin (box, compte Microsoft, e-mail…).';
    } else if (st === 'done') {
      kicker = 'Intervention terminée';
      title = 'C\'est réglé ✅';
      sub = 'Merci pour votre confiance !';
      note = 'Une question après l\'intervention ? Appelez ' + tech + ', il vous répondra avec plaisir.';
    }
    var lag = (Date.now() - lastOk) / 1000;
    if (st === 'enroute' && lag > 25) note += (note ? '<br>' : '') + '⚠︎ Connexion lente : dernière mise à jour il y a ' + Math.round(lag) + ' s.';
    setText('heroKicker', kicker);
    setText('heroTitle', title);
    setText('heroBig', big);
    $('heroBig').classList.toggle('slot', st === 'planned' && !!s.slot_end && !s.expired);
    setText('heroSub', sub);
    setText('heroNote', note);

    // étapes
    var idx = ORDER.indexOf(st);
    Array.prototype.forEach.call(document.querySelectorAll('#steps li'), function (li, i) {
      li.classList.toggle('done', i < idx || st === 'done');
      li.classList.toggle('now', i === idx && st !== 'done');
    });

    if (!skipMap) renderMap();
  }

  /* ───── Carte ───── */
  function ensureMap() {
    if (map || !F || !window.maplibregl) return !!map;
    try {
      map = F.createMap('map', {
        styleUrl: boot.styleUrl, workerUrl: boot.workerUrl,
        center: [state.dest.lon, state.dest.lat], zoom: 13, cooperative: false
      });
    } catch (err) {
      map = null;
      showMapMsg('La carte ne peut pas s\'afficher sur cet appareil, mais l\'heure d\'arrivée reste à jour.');
      return false;
    }
    home = new maplibregl.Marker({ element: F.homeElement(), anchor: 'bottom' })
      .setLngLat([state.dest.lon, state.dest.lat]).addTo(map);
    var stopFollow = function (e) { if (e && e.originalEvent) { follow = false; $('recenter').classList.remove('hidden'); } };
    map.on('dragstart', stopFollow);
    map.on('zoomstart', stopFollow);
    $('recenter').addEventListener('click', function () { follow = true; $('recenter').classList.add('hidden'); fit(true); });
    return true;
  }

  function showMapMsg(t) {
    var el = $('mapMsg');
    if (!t) { el.classList.add('hidden'); return; }
    el.textContent = t; el.classList.remove('hidden');
  }

  function fit(animate) {
    if (!map) return;
    var dest = [state.dest.lon, state.dest.lat];
    if (car && state.status === 'enroute' && state.pos) {
      var c = [state.pos.lon, state.pos.lat];
      var b = new maplibregl.LngLatBounds(c, c).extend(dest);
      var w = map.getContainer().clientWidth;
      map.fitBounds(b, { padding: { top: 80, bottom: 60, left: Math.min(70, w / 6), right: Math.min(70, w / 6) }, maxZoom: 15.5, duration: animate ? 900 : 0 });
    } else {
      map.easeTo({ center: dest, zoom: 14.5, duration: animate ? 900 : 0 });
    }
  }

  function renderMap() {
    var st = state.expired ? 'done' : state.status;
    var showMap = st === 'planned' || st === 'enroute';
    $('mapCard').classList.toggle('hidden', !showMap);
    if (!showMap) return;
    if (!ensureMap()) return;

    if (st === 'enroute' && state.pos) {
      var ll = [state.pos.lon, state.pos.lat];
      if (!car) {
        carEl = F.carElement('FixIT');
        car = new maplibregl.Marker({ element: carEl, anchor: 'center' }).setLngLat(ll).addTo(map);
      } else {
        F.animateTo(car, ll, 1800);
      }
      F.setHeading(carEl, state.pos.heading);
    } else if (car) {
      car.remove(); car = null; carEl = null;
    }
    if (st !== 'enroute') { F.setRoute(map, []); routeCoords = []; }
    else {
      if (state.route) routeCoords = state.route;
      F.setRoute(map, state.pos ? F.remaining(routeCoords, state.pos.lon, state.pos.lat) : routeCoords);
    }

    if (st === 'enroute' && state.hidden) showMapMsg('Votre technicien vient de partir : sa position apparaîtra sur la carte dans quelques instants.');
    else if (st === 'enroute' && state.stale) showMapMsg('Signal GPS momentanément perdu (dernière position il y a ' + Math.max(1, Math.round((now() - state.last_seen) / 60)) + ' min). L\'heure d\'arrivée reste estimée.');
    else if (st === 'enroute' && !state.pos) showMapMsg('Localisation du technicien en cours…');
    else showMapMsg('');

    if (follow || !fitted) { fit(fitted); fitted = true; }
  }

  /* ───── Mise à jour ───── */
  function schedule() {
    clearTimeout(pollTimer);
    if (document.hidden) return;
    var st = state.status;
    if (state.expired || st === 'done') return;
    var delay = st === 'enroute' ? 4000 : 30000;
    if (failures) delay = Math.min(30000, delay * (1 + failures));
    pollTimer = setTimeout(poll, delay);
  }

  function poll() {
    var url = boot.statusUrl + '?k=' + encodeURIComponent(boot.token) + '&v=' + routeV;
    var ctrl = ('AbortController' in window) ? new AbortController() : null;
    var to = setTimeout(function () { if (ctrl) ctrl.abort(); }, 10000);
    fetch(url, { cache: 'no-store', credentials: 'omit', signal: ctrl ? ctrl.signal : undefined })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (s) {
        failures = 0; lastOk = Date.now();
        offset = s.now - Date.now() / 1000;
        if (s.route) routeV = s.route_v;
        if (s.status !== state.status) { follow = true; }
        state = s;
        render();
      })
      .catch(function () { failures++; render(true); })
      .then(function () { clearTimeout(to); schedule(); });
  }

  /* ───── Estimation de position entre deux signaux (zones de faible réseau) ─────
     Si la dernière position date de quelques secondes, la voiture continue d'avancer
     sur l'itinéraire à sa dernière vitesse connue (au maximum 25 s), puis s'arrête. */
  function advanceAlong(coords, lon, lat, meters) {
    var pr = F.project(coords, lon, lat);
    if (!pr || pr.d > 60) return null; // trop loin du tracé : on ne devine pas
    var kx = 111320 * Math.cos(lat * Math.PI / 180), ky = 110540, bi = pr.i, cur = pr.pt;
    var left = meters;
    for (var j = bi + 1; j < coords.length; j++) {
      var seg = Math.hypot((coords[j][0] - cur[0]) * kx, (coords[j][1] - cur[1]) * ky);
      if (seg >= left) { var f = seg ? left / seg : 0; return [cur[0] + (coords[j][0] - cur[0]) * f, cur[1] + (coords[j][1] - cur[1]) * f]; }
      left -= seg; cur = coords[j];
    }
    return cur;
  }
  setInterval(function () {
    if (!car || state.status !== 'enroute' || !state.pos || state.hidden) return;
    var sp = state.pos.speed, age = now() - state.pos.ts;
    if (!sp || sp < 2 || age < 3 || age > 40) return;
    var p = advanceAlong(routeCoords, state.pos.lon, state.pos.lat, sp * Math.min(age, 25) * 0.9);
    if (p) { F.animateTo(car, p, 950); F.setRoute(map, F.remaining(routeCoords, p[0], p[1])); }
  }, 1000);

  document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(); else clearTimeout(pollTimer); });
  setInterval(function () { if (state.status === 'enroute') render(true); }, 5000);

  offset = state.now - Date.now() / 1000;
  if (state.route) routeV = state.route_v;
  render();
  schedule();
})();
