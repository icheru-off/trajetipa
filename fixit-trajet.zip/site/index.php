<?php
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';
if (!is_installed()) redirect('install.php');
if (is_admin()) redirect('admin/');
page_head('FixIT – Suivi d\'intervention');
?>
<body>
<div class="login"><div class="card" style="text-align:center">
  <img class="logo" src="<?= h(asset('img/logo-light.png')) ?>" alt="FixIT">
  <h2>Suivi d'intervention</h2>
  <p class="muted">Pour suivre l'arrivée de votre technicien, ouvrez le lien personnel reçu par SMS ou e-mail.</p>
  <a class="btn btn-block" href="https://fixit-service.fr">Aller sur fixit-service.fr</a>
</div></div>
</body>
</html>
