<?php
/**
 * API de l'application iPhone « FixIT Trajet ».
 * Authentification : en-tête  X-App-Key: <clé>  (clé visible dans Réglages › Application iPhone).
 * Corps JSON : {"action": "...", ...}
 */
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
if (!is_installed()) json_out(['error' => 'install'], 503);

$key = app_key();
$given = (string)($_SERVER['HTTP_X_APP_KEY'] ?? '');
if ($given === '') {
    $auth = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ''));
    if (stripos($auth, 'bearer ') === 0) $given = trim(substr($auth, 7));
}
if (!hash_equals($key, $given)) {
    usleep(300000);
    json_out(['error' => 'auth', 'message' => 'Clé de l\'application invalide'], 401);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['error' => 'method'], 405);

$in = json_decode((string)file_get_contents('php://input'), true) ?: [];
$action = (string)($in['action'] ?? '');
set_setting('app_last_seen', (string)time());

function app_iv_summary(array $iv): array
{
    $m = build_messages($iv);
    return [
        'id' => (int)$iv['id'],
        'client' => iv_title($iv),
        'phone' => phone_e164($iv['client_phone']),
        'address' => $iv['address'],
        'address_extra' => (string)$iv['address_extra'],
        'lat' => (float)$iv['lat'],
        'lon' => (float)$iv['lon'],
        'scheduled_at' => (int)$iv['scheduled_at'],
        'slot_end' => iv_slot_end($iv),
        'status' => $iv['status'],
        'status_label' => STATUS_LABELS[$iv['status']] ?? $iv['status'],
        'link' => client_link($iv['token']),
        'msg_enroute' => $m['enroute']['text'],
    ];
}

function app_state(array $iv, int $knownV): array
{
    $s = [
        'id' => (int)$iv['id'],
        'status' => $iv['status'],
        'now' => time(),
        'route_v' => (int)$iv['route_v'],
        'eta' => null,
        'provider' => $iv['route_provider'],
        'speed' => $iv['pos_speed'] !== null ? round((float)$iv['pos_speed'], 1) : null,
    ];
    if ($iv['status'] === 'enroute' && $iv['eta_at']) {
        $s['eta'] = [
            'at' => (int)$iv['eta_at'], 'low' => (int)$iv['eta_low'], 'high' => (int)$iv['eta_high'],
            'dist_m' => (int)round((float)$iv['route_dist_m']), 'traffic' => (bool)$iv['route_traffic'],
            'jam' => (bool)($iv['eta_jam'] ?? 0),
        ];
    }
    if ($knownV !== (int)$iv['route_v']) {
        $s['route'] = $iv['route_json'] ? (json_decode($iv['route_json'], true) ?: []) : [];
    }
    return $s;
}

$id = (int)($in['id'] ?? 0);
$knownV = (int)($in['v'] ?? -1);

switch ($action) {
    case 'ping':
        json_out(['ok' => true, 'tech' => tech_name(), 'now' => time(), 'version' => APP_VERSION]);

    case 'list':
        $st = db()->prepare("SELECT * FROM interventions
            WHERE status IN ('enroute','arrived','working')
               OR (status = 'planned' AND scheduled_at >= ? AND scheduled_at < ?)
            ORDER BY CASE status WHEN 'enroute' THEN 0 WHEN 'arrived' THEN 1 WHEN 'working' THEN 2 ELSE 3 END, scheduled_at
            LIMIT 60");
        $st->execute([strtotime('today') - 86400, strtotime('today') + 8 * 86400]);
        json_out(['ok' => true, 'now' => time(), 'items' => array_map('app_iv_summary', $st->fetchAll())]);

    case 'depart':
        $iv = get_iv($id) ?? json_out(['error' => 'notfound'], 404);
        $lat = isset($in['lat']) && is_numeric($in['lat']) ? (float)$in['lat'] : null;
        $lon = isset($in['lon']) && is_numeric($in['lon']) ? (float)$in['lon'] : null;
        $iv = start_trip($iv, $lat, $lon);
        json_out(['ok' => true, 'state' => app_state($iv, -1), 'item' => app_iv_summary($iv)]);

    case 'points':
        $iv = get_iv($id) ?? json_out(['error' => 'notfound'], 404);
        $pts = is_array($in['points'] ?? null) ? $in['points'] : [];
        $received = count($pts);
        if ($iv['status'] === 'enroute' && $pts) $iv = ingest_points($iv, $pts, 'app');
        // on accuse réception même si le trajet est terminé : l'app vide alors sa file d'attente
        json_out(['ok' => true, 'received' => $received, 'state' => app_state($iv, $knownV)]);

    case 'arrived':
        $iv = get_iv($id) ?? json_out(['error' => 'notfound'], 404);
        $iv = $iv['status'] === 'enroute' ? mark_arrived($iv) : $iv;
        json_out(['ok' => true, 'state' => app_state($iv, $knownV)]);

    case 'stop':
        $iv = get_iv($id) ?? json_out(['error' => 'notfound'], 404);
        if ($iv['status'] === 'enroute') update_iv($id, ['status' => 'planned', 'eta_at' => null, 'trip_started_at' => null]);
        db()->prepare('DELETE FROM positions WHERE iv_id = ?')->execute([$id]);
        json_out(['ok' => true, 'state' => app_state(get_iv($id), $knownV)]);

    // Rappels SMS : liste pour les notifications de l'app (à venir + à envoyer)
    case 'reminders':
        $items = array_map(fn($r) => [
            'id' => $r['iv_id'], 'rule' => $r['rule'], 'sched' => $r['sched'], 'due' => $r['due'], 'state' => $r['state'],
            'label' => $r['label'], 'client' => $r['client'], 'phone' => '+' . $r['phone'], 'text' => $r['text'],
        ], reminders_upcoming(null, 8));
        json_out(['ok' => true, 'now' => time(), 'items' => $items]);

    // Rappels SMS à envoyer maintenant (automatisation Raccourcis de l'iPhone)
    case 'reminders_due':
        set_setting('reminders_auto_seen', (string)time());
        $items = array_map(fn($r) => [
            'id' => $r['iv_id'], 'rule' => $r['rule'], 'sched' => $r['sched'],
            'client' => $r['client'], 'phone' => '+' . $r['phone'], 'text' => $r['text'],
        ], reminders_due());
        json_out(['ok' => true, 'count' => count($items), 'items' => $items]);

    case 'reminder_sent':
        $iv = get_iv($id) ?? json_out(['error' => 'notfound'], 404);
        $rule = (string)($in['rule'] ?? '');
        $sched = (int)($in['sched'] ?? 0);
        if (!in_array($rule, array_column(reminder_defaults(), 'id'), true) || $sched !== (int)$iv['scheduled_at']) json_out(['error' => 'rule'], 400);
        reminder_mark($id, $rule, $sched, (string)($in['via'] ?? 'auto'));
        json_out(['ok' => true]);

    case 'state':
        $iv = get_iv($id) ?? json_out(['error' => 'notfound'], 404);
        json_out(['ok' => true, 'state' => app_state($iv, $knownV), 'item' => app_iv_summary($iv)]);

    default:
        json_out(['error' => 'action'], 400);
}
