<?php
/** Réception des positions envoyées par le mode trajet (navigateur de l'iPhone). */
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin(true);
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_check()) json_out(['error' => 'csrf'], 403);

$in = json_decode((string)file_get_contents('php://input'), true) ?: [];
$iv = get_iv((int)($in['id'] ?? 0));
if (!$iv) json_out(['error' => 'notfound'], 404);
$num = fn($k) => isset($in[$k]) && is_numeric($in[$k]) ? (float)$in[$k] : null;

$lat = $num('lat');
$lon = $num('lon');
if ($iv['status'] === 'enroute' && !empty($in['points']) && is_array($in['points'])) {
    // lot de positions mises en attente pendant une coupure réseau
    $iv = ingest_points($iv, $in['points'], 'web');
} elseif ($iv['status'] === 'enroute' && $lat !== null && $lon !== null) {
    $speed = $num('speed');
    $heading = $num('heading');
    if ($speed !== null && $speed < 0) $speed = null;
    if ($heading !== null && ($heading < 0 || $heading > 360)) $heading = null;
    $ts = $num('ts');
    $iv = process_position($iv, $lat, $lon, $num('acc'), $speed, $heading, $ts ? (int)round($ts) : time(), 'web');
}
$state = public_state($iv, (int)($in['v'] ?? -1));
// le technicien voit toujours sa position et tout son tracé (pas de zone masquée pour lui)
if ($iv['pos_lat'] !== null) $state['pos'] = ['lat' => (float)$iv['pos_lat'], 'lon' => (float)$iv['pos_lon'], 'heading' => $iv['pos_heading'] !== null ? (float)$iv['pos_heading'] : null];
if (isset($state['route']) || ((int)($in['v'] ?? -1)) !== (int)$iv['route_v']) {
    $state['route'] = $iv['route_json'] ? (json_decode($iv['route_json'], true) ?: []) : [];
}
$state['provider'] = $iv['route_provider'];
$state['speed'] = $iv['pos_speed'] !== null ? (float)$iv['pos_speed'] : null;
$state['factor'] = $iv['eta_factor'] !== null ? (float)$iv['eta_factor'] : null;
json_out($state);
