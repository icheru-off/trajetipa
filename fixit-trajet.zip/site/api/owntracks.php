<?php
/**
 * Point d'entrée pour l'application iPhone gratuite « OwnTracks » (mode HTTP).
 * Permet le suivi même écran verrouillé. URL à coller dans OwnTracks : voir Réglages.
 */
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
if (!is_installed()) json_out([], 503);

$key = (string)setting('owntracks_key', '');
$given = (string)($_GET['key'] ?? '');
if ($given === '') {
    // identifiants « Basic » (mot de passe = clé)
    $given = (string)($_SERVER['PHP_AUTH_PW'] ?? '');
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if ($given === '' && stripos((string)$auth, 'basic ') === 0) {
        $dec = base64_decode(substr((string)$auth, 6), true) ?: '';
        $given = (string)substr($dec, (int)strpos($dec, ':') + 1);
    }
}
if ($key === '' || !hash_equals($key, $given)) json_out(['error' => 'auth'], 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out([]);

$p = json_decode((string)file_get_contents('php://input'), true);
set_setting('owntracks_last', (string)time());
if (!is_array($p) || ($p['_type'] ?? '') !== 'location' || !isset($p['lat'], $p['lon'])) json_out([]);

$iv = db()->query("SELECT * FROM interventions WHERE status = 'enroute' ORDER BY trip_started_at DESC LIMIT 1")->fetch();
if ($iv) {
    // OwnTracks : vel en km/h, cog en degrés, acc en mètres, tst en secondes
    $speed = isset($p['vel']) && is_numeric($p['vel']) ? (float)$p['vel'] / 3.6 : null;
    $heading = isset($p['cog']) && is_numeric($p['cog']) ? (float)$p['cog'] : null;
    $acc = isset($p['acc']) && is_numeric($p['acc']) ? (float)$p['acc'] : null;
    $ts = isset($p['tst']) && is_numeric($p['tst']) ? (int)$p['tst'] : time();
    process_position($iv, (float)$p['lat'], (float)$p['lon'], $acc, $speed, $heading, $ts, 'owntracks');
}
// aucune position n'est conservée hors trajet
json_out([]);
