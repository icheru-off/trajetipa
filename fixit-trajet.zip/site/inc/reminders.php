<?php
/**
 * Rappels SMS avant intervention (la veille au soir, quelques heures avant, etc.).
 * Les règles se règlent dans Réglages ; l'envoi se fait depuis votre téléphone :
 *  - en un geste (tableau de bord, fiche, notification de l'app iPhone),
 *  - ou tout seul via une automatisation Raccourcis de l'iPhone (api/app.php, actions reminders_due / reminder_sent).
 */
declare(strict_types=1);

const REMINDER_VARS = [
    '{bonjour}' => '« Bonjour Mme Martin » (ou « Bonjour » sans nom)',
    '{nom}' => 'nom du client',
    '{quand}' => '« demain », « aujourd\'hui » ou « le jeudi 20 novembre »',
    '{date}' => 'jeudi 20 novembre',
    '{creneau}' => '« entre 14h00 et 14h30 » ou « vers 14h00 »',
    '{heure}' => '14h00',
    '{adresse}' => 'adresse de l\'intervention',
    '{lien}' => 'lien de suivi en direct',
    '{technicien}' => 'votre prénom',
    '{telephone}' => 'votre téléphone pro',
];

function reminder_defaults(): array
{
    return [
        [
            'id' => 'r1', 'on' => true, 'kind' => 'days', 'days' => 1, 'at' => '18:00', 'minutes' => 120,
            'text' => "{bonjour}, petit rappel : je passe chez vous {quand} {creneau} pour votre dépannage informatique, au {adresse}.\n\n"
                . "Vous pourrez suivre mon arrivée en direct sur ce lien :\n{lien}\n\n"
                . "Un empêchement ? Prévenez-moi au {telephone}.\n{technicien} – FixIT",
        ],
        [
            'id' => 'r2', 'on' => false, 'kind' => 'minutes', 'days' => 0, 'at' => '08:00', 'minutes' => 120,
            'text' => "{bonjour}, je serai chez vous aujourd'hui {creneau}. Suivez mon arrivée en direct dès mon départ :\n{lien}\n\n"
                . "{technicien} – FixIT · {telephone}",
        ],
        [
            'id' => 'r3', 'on' => false, 'kind' => 'days', 'days' => 3, 'at' => '10:00', 'minutes' => 120,
            'text' => "{bonjour}, je vous confirme notre rendez-vous {quand} {creneau}, au {adresse}.\n\n"
                . "Pensez à préparer l'appareil concerné et les mots de passe utiles (session, box, messagerie).\n\n"
                . "Un empêchement ? {telephone}\n{technicien} – FixIT",
        ],
    ];
}

/** Règles enregistrées (3 emplacements), complétées par les valeurs par défaut. */
function reminder_rules(): array
{
    $saved = json_decode((string)setting('reminder_rules', ''), true);
    $out = [];
    foreach (reminder_defaults() as $i => $d) {
        $r = is_array($saved[$i] ?? null) ? array_merge($d, array_intersect_key($saved[$i], $d)) : $d;
        $r['id'] = $d['id'];
        $r['on'] = (bool)$r['on'];
        $r['kind'] = $r['kind'] === 'minutes' ? 'minutes' : 'days';
        $r['days'] = max(0, min(14, (int)$r['days']));
        $r['minutes'] = max(15, min(48 * 60, (int)$r['minutes']));
        $r['at'] = preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string)$r['at']) ? $r['at'] : $d['at'];
        $r['text'] = trim((string)$r['text']) !== '' ? (string)$r['text'] : $d['text'];
        $out[] = $r;
    }
    return $out;
}

/** « La veille à 18h00 », « 2 h avant le rendez-vous »… */
function reminder_label(array $r): string
{
    if ($r['kind'] === 'minutes') {
        $m = (int)$r['minutes'];
        $t = $m % 60 ? ($m >= 60 ? intdiv($m, 60) . ' h ' . sprintf('%02d', $m % 60) : $m . ' min') : intdiv($m, 60) . ' h';
        return $t . ' avant le rendez-vous';
    }
    $at = str_replace(':', 'h', $r['at']);
    return match ((int)$r['days']) {
        0 => 'Le jour même à ' . $at,
        1 => 'La veille à ' . $at,
        7 => 'Une semaine avant, à ' . $at,
        default => $r['days'] . ' jours avant, à ' . $at,
    };
}

/** Heure d'envoi prévue pour une intervention. */
function reminder_due_at(array $r, int $sched): int
{
    if ($r['kind'] === 'minutes') return $sched - (int)$r['minutes'] * 60;
    [$h, $m] = array_map('intval', explode(':', $r['at']));
    $day = strtotime(date('Y-m-d', $sched) . ' 00:00:00 -' . (int)$r['days'] . ' days');
    return (int)mktime($h, $m, 0, (int)date('n', $day), (int)date('j', $day), (int)date('Y', $day));
}

/** Texte final du rappel. */
function reminder_text(array $r, array $iv, ?int $due = null): string
{
    $sched = (int)$iv['scheduled_at'];
    $due ??= reminder_due_at($r, $sched);
    $dSched = date('Y-m-d', $sched);
    $quand = $dSched === date('Y-m-d', $due) ? "aujourd'hui"
        : ($dSched === date('Y-m-d', $due + 86400) ? 'demain' : 'le ' . fr_date($sched));
    $n = trim((string)$iv['client_name']);
    $vars = [
        '{bonjour}' => $n !== '' ? "Bonjour $n" : 'Bonjour',
        '{nom}' => $n,
        '{quand}' => $quand,
        '{date}' => fr_date($sched),
        '{creneau}' => iv_slot($iv),
        '{heure}' => fr_time($sched),
        '{adresse}' => trim((string)$iv['address']),
        '{lien}' => client_link((string)$iv['token']),
        '{technicien}' => tech_name(),
        '{telephone}' => tech_phone(),
    ];
    $t = strtr($r['text'], $vars);
    $t = preg_replace('/ {2,}/', ' ', $t);               // variable vide → pas de double espace
    return trim(str_replace(' ,', ',', $t));
}

function reminder_sent_map(int $ivId, int $sched): array
{
    $st = db()->prepare('SELECT rule_id, sent_at, via FROM reminder_log WHERE iv_id = ? AND sched_at = ?');
    $st->execute([$ivId, $sched]);
    $out = [];
    foreach ($st->fetchAll() as $row) $out[$row['rule_id']] = $row;
    return $out;
}

/**
 * Rappels d'une intervention.
 * state : sent · due (à envoyer maintenant) · upcoming · missed (rendez-vous passé) · late (pris après l'heure du rappel)
 *         · skipped (un rappel plus récent est aussi à envoyer)
 *         · nophone · off (rappels désactivés pour ce client)
 */
function iv_reminders(array $iv, ?int $now = null): array
{
    $now ??= now_ts();
    $sched = (int)$iv['scheduled_at'];
    $sent = reminder_sent_map((int)$iv['id'], $sched);
    $phone = phone_e164($iv['client_phone'] ?? '');
    $out = [];
    foreach (reminder_rules() as $r) {
        if (!$r['on']) continue;
        $due = reminder_due_at($r, $sched);
        $s = $sent[$r['id']] ?? null;
        if ($s) $state = 'sent';
        elseif (!empty($iv['reminders_off'])) $state = 'off';
        elseif ($iv['status'] !== 'planned' || $now >= $sched) $state = 'missed';
        elseif ((int)$iv['created_at'] > $due + 60) $state = 'late';
        elseif ($phone === '') $state = 'nophone';
        elseif ($now >= $due) $state = 'due';
        else $state = 'upcoming';
        $out[] = [
            'rule' => $r['id'],
            'label' => reminder_label($r),
            'due' => $due,
            'state' => $state,
            'sent_at' => $s ? (int)$s['sent_at'] : null,
            'via' => $s['via'] ?? null,
            'phone' => $phone,
            'text' => reminder_text($r, $iv, $due),
        ];
    }
    // plusieurs rappels en retard pour le même rendez-vous : on n'envoie que le plus récent,
    // et jamais un rappel plus ancien qu'un rappel déjà envoyé
    $lastSent = max([0, ...array_map(fn($x) => $x['due'], array_filter($out, fn($x) => $x['state'] === 'sent'))]);
    foreach ($out as $k => $x) if ($x['state'] === 'due' && $x['due'] <= $lastSent) $out[$k]['state'] = 'skipped';
    $dues = array_keys(array_filter($out, fn($x) => $x['state'] === 'due'));
    if (count($dues) > 1) {
        usort($dues, fn($a, $b) => $out[$b]['due'] <=> $out[$a]['due']);
        foreach (array_slice($dues, 1) as $k) $out[$k]['state'] = 'skipped';
    }
    return $out;
}

/** Interventions planifiées dans les 15 prochains jours (fenêtre utile aux rappels). */
function reminder_candidates(?int $now = null): array
{
    $now ??= now_ts();
    $st = db()->prepare("SELECT * FROM interventions WHERE status = 'planned' AND scheduled_at > ? AND scheduled_at < ? ORDER BY scheduled_at");
    $st->execute([$now, $now + 15 * 86400]);
    return $st->fetchAll();
}

/** Rappels à envoyer maintenant (état « due »), toutes interventions confondues. */
function reminders_due(?int $now = null, int $aheadSec = 0): array
{
    $now ??= now_ts();
    $out = [];
    foreach (reminder_candidates($now) as $iv) {
        foreach (iv_reminders($iv, $now + $aheadSec) as $rem) {
            if ($rem['state'] === 'due' || ($aheadSec && $rem['state'] === 'upcoming' && $rem['due'] <= $now + $aheadSec)) {
                $out[] = $rem + ['iv_id' => (int)$iv['id'], 'sched' => (int)$iv['scheduled_at'], 'client' => iv_title($iv), 'iv' => $iv];
            }
        }
    }
    usort($out, fn($a, $b) => $a['due'] <=> $b['due']);
    return $out;
}

/** Rappels à venir (pour programmer les notifications de l'app iPhone). */
function reminders_upcoming(?int $now = null, int $days = 8): array
{
    $now ??= now_ts();
    $out = [];
    foreach (reminder_candidates($now) as $iv) {
        foreach (iv_reminders($iv, $now) as $rem) {
            if (in_array($rem['state'], ['due', 'upcoming'], true) && $rem['due'] < $now + $days * 86400) {
                $out[] = $rem + ['iv_id' => (int)$iv['id'], 'sched' => (int)$iv['scheduled_at'], 'client' => iv_title($iv)];
            }
        }
    }
    usort($out, fn($a, $b) => $a['due'] <=> $b['due']);
    return $out;
}

function reminder_mark(int $ivId, string $ruleId, int $sched, string $via = 'sms'): void
{
    db()->prepare('INSERT OR REPLACE INTO reminder_log(iv_id, rule_id, sched_at, sent_at, via) VALUES(?,?,?,?,?)')
        ->execute([$ivId, $ruleId, $sched, now_ts(), mb_substr($via, 0, 20)]);
}

function reminder_unmark(int $ivId, string $ruleId, int $sched): void
{
    db()->prepare('DELETE FROM reminder_log WHERE iv_id = ? AND rule_id = ? AND sched_at = ?')->execute([$ivId, $ruleId, $sched]);
}

/* ───────────── Affichage (tableau de bord, fiche) ───────────── */

function reminder_state_label(array $rem): array
{
    $due = (int)$rem['due'];
    $when = (date('Y-m-d', $due) === date('Y-m-d', now_ts()) ? "aujourd'hui" : fr_date($due)) . ' à ' . fr_time($due);
    return match ($rem['state']) {
        'sent' => ['sent', '✓ Envoyé ' . ($rem['sent_at'] ? fr_relative_day((int)$rem['sent_at']) . ' à ' . fr_time((int)$rem['sent_at']) : '') . ($rem['via'] === 'auto' ? ' (automatique)' : '')],
        'due' => ['due', 'À envoyer maintenant'],
        'upcoming' => ['', 'Prévu ' . $when],
        'missed' => ['warn', 'Non envoyé'],
        'late' => ['', 'Rendez-vous pris après l\'heure du rappel'],
        'skipped' => ['', 'Remplacé par un rappel plus récent'],
        'nophone' => ['warn', 'Pas de numéro de mobile'],
        'off' => ['', 'Rappels désactivés pour ce client'],
        default => ['', ''],
    };
}

function reminder_card(array $iv, array $rem, bool $withClient = false): string
{
    [$cls, $txt] = reminder_state_label($rem);
    $actionable = in_array($rem['state'], ['due', 'upcoming', 'missed'], true) && $rem['phone'] !== '';
    $head = $withClient
        ? '<b><a href="' . h(base_url('admin/view.php?id=' . $iv['id'])) . '">' . h(iv_title($iv)) . '</a></b><span class="rem-sub">' . h($rem['label']) . ' · RDV ' . h(fr_relative_day((int)$iv['scheduled_at']) . ' ' . iv_slot($iv)) . '</span>'
        : '<b>' . h($rem['label']) . '</b>';
    ob_start(); ?>
    <div class="rem <?= $rem['state'] === 'due' ? 'due' : '' ?> <?= $rem['state'] === 'sent' ? 'done' : '' ?>" data-rem
         data-iv="<?= (int)$iv['id'] ?>" data-rule="<?= h($rem['rule']) ?>" data-sched="<?= (int)$iv['scheduled_at'] ?>"
         data-phone="<?= h($rem['phone']) ?>" data-csrf="<?= h(csrf_token()) ?>" data-url="<?= h(base_url('admin/action.php')) ?>">
      <div class="rem-head"><div><?= $head ?></div><span class="state <?= $cls ?>" data-rem-state><?= h($txt) ?></span></div>
      <?php if ($actionable || $rem['state'] === 'sent'): ?>
        <textarea aria-label="Texte du rappel"><?= h($rem['text']) ?></textarea>
        <div class="actions">
          <button class="btn btn-sm btn-primary" type="button" data-rem-act="sms"><?= icon('sms') ?>SMS</button>
          <button class="btn btn-sm" type="button" data-rem-act="wa"><?= icon('wa') ?>WhatsApp</button>
          <button class="btn btn-sm" type="button" data-rem-act="copy"><?= icon('copy') ?>Copier</button>
          <button class="btn btn-sm" type="button" data-rem-act="mark"><?= icon('check') ?>Déjà envoyé</button>
          <button class="btn btn-sm" type="button" data-rem-act="undo" hidden>Annuler « envoyé »</button>
        </div>
      <?php endif; ?>
    </div>
    <?php return (string)ob_get_clean();
}
