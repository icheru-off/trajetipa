<?php
/**
 * Moteur d'heure d'arrivée estimée.
 *
 * 1. Itinéraire réel (OSRM = réseau routier OpenStreetMap avec les limitations de vitesse,
 *    ou TomTom = trafic temps réel, bouchons et accidents compris, si une clé gratuite est configurée).
 * 2. Modèle de circulation Île-de-France / Seine-et-Marne selon le jour et l'heure (heures de pointe…),
 *    utilisé quand le trafic temps réel n'est pas disponible.
 * 3. Correction « terrain » : pendant le trajet on compare la vitesse réellement constatée
 *    à la prévision. Un bouchon ou un accident ralentit la progression → l'heure d'arrivée recule
 *    automatiquement, même sans données de trafic.
 * 4. Apprentissage : à chaque arrivée, l'écart réel / prévu affine le coefficient personnel du technicien.
 */
declare(strict_types=1);

const ARRIVE_RADIUS_M = 120;     // rayon considéré comme « arrivé »
const ROUTE_EVERY_S = 30;        // recalcul d'itinéraire (OSRM)
const ROUTE_EVERY_TT_S = 60;     // recalcul d'itinéraire (TomTom, pour économiser le quota)
const OFF_ROUTE_M = 220;         // écart à l'itinéraire déclenchant un recalcul immédiat
const MAX_ACCURACY_M = 250;      // positions GPS trop imprécises ignorées

/** Horloge (surchargeable pour les tests de simulation). */
function now_ts(): int
{
    return isset($GLOBALS['__fixit_now']) ? (int)$GLOBALS['__fixit_now'] : time();
}

/** Coefficient de circulation « habituelle » selon le jour et l'heure (heure de Paris). */
function tod_factor(int $ts): float
{
    $dow = (int)date('N', $ts); // 1 = lundi … 7 = dimanche
    $h = (int)date('G', $ts) + ((int)date('i', $ts)) / 60;
    $holidays = in_array(date('m-d', $ts), ['01-01', '05-01', '05-08', '07-14', '08-15', '11-01', '11-11', '12-25'], true);
    if ($dow === 7 || $holidays) {
        return ($h >= 10 && $h < 19) ? 1.06 : 1.02;
    }
    if ($dow === 6) {
        if ($h >= 10 && $h < 13) return 1.15;
        if ($h >= 13 && $h < 19) return 1.18;
        return 1.04;
    }
    // jours de semaine
    if ($h < 6) return 1.0;
    if ($h < 7) return 1.10;
    if ($h < 9.5) return ($dow === 3 ? 1.28 : 1.35);   // pointe du matin (un peu moins le mercredi)
    if ($h < 11.5) return 1.14;
    if ($h < 14) return 1.18;
    if ($h < 16.5) return 1.15;
    if ($h < 19.5) return ($dow === 5 ? 1.45 : 1.40);   // pointe du soir (pire le vendredi)
    if ($h < 21) return 1.14;
    return 1.03;
}

/** Coefficient personnel appris (écart entre ses trajets réels et la prévision brute). */
function learned_factor(bool $traffic): float
{
    return (float)setting($traffic ? 'learn_tt' : 'learn_osrm', $traffic ? '1.0' : '1.10');
}

function parking_buffer_s(): int
{
    return max(0, (int)setting('parking_min', 2)) * 60;
}

/**
 * Démarre un trajet vers l'intervention.
 */
function start_trip(array $iv, ?float $lat = null, ?float $lon = null): array
{
    $now = now_ts();
    // un seul trajet actif à la fois
    db()->prepare("UPDATE interventions SET status='planned', updated_at=? WHERE status='enroute' AND id <> ?")
        ->execute([$now, $iv['id']]);
    db()->prepare('DELETE FROM positions WHERE iv_id = ?')->execute([$iv['id']]);
    update_iv((int)$iv['id'], [
        'status' => 'enroute', 'trip_started_at' => $now, 'move_started_at' => null,
        'origin_lat' => $lat, 'origin_lon' => $lon,
        'base_raw_s' => null, 'base_at' => null, 'base_provider' => null,
        'route_json' => null, 'route_at' => null, 'route_raw_s' => null, 'route_dist_m' => null,
        'route_provider' => null, 'route_traffic' => 0, 'route_hist' => null,
        'eta_at' => null, 'eta_low' => null, 'eta_high' => null, 'eta_factor' => null, 'eta_updated' => null, 'eta_jam' => 0,
        'first_eta_at' => null, 'pos_lat' => null, 'pos_lon' => null, 'pos_acc' => null, 'pos_speed' => null,
        'pos_heading' => null, 'pos_ts' => null, 'near_count' => 0,
        'arrived_at' => null, 'started_at' => null, 'done_at' => null,
    ]);
    $iv = get_iv((int)$iv['id']);
    if ($lat !== null && $lon !== null) {
        $iv = process_position($iv, $lat, $lon, null, null, null, $now, 'depart');
    }
    return $iv;
}

/**
 * Traite une nouvelle position GPS du technicien et met à jour l'heure d'arrivée.
 * $speed en m/s, $heading en degrés (0 = nord).
 */
function process_position(array $iv, float $lat, float $lon, ?float $acc, ?float $speed, ?float $heading, int $ts, string $source, bool $allowRoute = true): array
{
    if ($iv['status'] !== 'enroute') return $iv;
    if (abs($lat) > 90 || abs($lon) > 180) return $iv;
    if ($acc !== null && $acc > MAX_ACCURACY_M) return $iv;
    $now = now_ts();
    if ($ts > $now + 60 || $ts < $now - 3600) $ts = $now;
    if ($iv['pos_ts'] && $ts < (int)$iv['pos_ts']) return $iv; // position plus ancienne que la dernière connue

    $id = (int)$iv['id'];
    $f = [];

    // vitesse / cap déduits si le téléphone ne les donne pas
    if ($iv['pos_lat'] !== null && $iv['pos_ts']) {
        $dt = $ts - (int)$iv['pos_ts'];
        $d = haversine((float)$iv['pos_lat'], (float)$iv['pos_lon'], $lat, $lon);
        if ($speed === null && $dt > 0) $speed = $d / $dt;
        if ($heading === null && $d > 8) $heading = bearing((float)$iv['pos_lat'], (float)$iv['pos_lon'], $lat, $lon);
    }
    if ($heading === null && $iv['pos_heading'] !== null) $heading = (float)$iv['pos_heading'];
    if ($speed !== null && ($speed > 70 || $speed < 0)) $speed = null; // > 250 km/h : saut GPS, ignoré

    db()->prepare('INSERT INTO positions(iv_id, lat, lon, acc, speed, heading, ts) VALUES(?,?,?,?,?,?,?)')
        ->execute([$id, $lat, $lon, $acc, $speed, $heading, $ts]);
    db()->prepare('DELETE FROM positions WHERE iv_id = ? AND id NOT IN (SELECT id FROM positions WHERE iv_id = ? ORDER BY ts DESC LIMIT 400)')
        ->execute([$id, $id]);

    $f += ['pos_lat' => $lat, 'pos_lon' => $lon, 'pos_acc' => $acc, 'pos_speed' => $speed, 'pos_heading' => $heading, 'pos_ts' => $ts, 'pos_source' => $source];

    if ($iv['origin_lat'] === null) {
        $f['origin_lat'] = $lat;
        $f['origin_lon'] = $lon;
        $iv['origin_lat'] = $lat;
        $iv['origin_lon'] = $lon;
    }

    // début réel du mouvement (on ne compte pas le temps passé à rejoindre la voiture)
    if (!$iv['move_started_at']) {
        $fromOrigin = haversine((float)$iv['origin_lat'], (float)$iv['origin_lon'], $lat, $lon);
        if ($fromOrigin > 150 || ($speed !== null && $speed > 3.5)) {
            $f['move_started_at'] = $ts;
            $iv['move_started_at'] = $ts;
        }
    }

    // arrivée automatique
    $destLat = (float)$iv['lat'];
    $destLon = (float)$iv['lon'];
    $distDest = haversine($lat, $lon, $destLat, $destLon);
    $near = $distDest <= ARRIVE_RADIUS_M ? ((int)$iv['near_count'] + 1) : 0;
    $f['near_count'] = $near;
    if (($near >= 2 || $distDest <= 40) && $source !== 'depart') {
        update_iv($id, $f);
        return mark_arrived(get_iv($id));
    }

    // faut-il recalculer l'itinéraire ?
    $coords = $iv['route_json'] ? (json_decode($iv['route_json'], true) ?: []) : [];
    $every = $iv['route_traffic'] ? ROUTE_EVERY_TT_S : ROUTE_EVERY_S;
    $offRoute = $coords ? dist_to_polyline($lat, $lon, $coords) : INF;
    $need = ($allowRoute && (!$iv['route_at'] || ($now - (int)$iv['route_at']) >= $every || $offRoute > OFF_ROUTE_M))
        || ($iv['move_started_at'] && !$iv['base_raw_s']); // référence de mesure, même au milieu d'un lot

    if ($need) {
        $r = compute_route($lat, $lon, $destLat, $destLon);
        if (!$r) {
            // secours : distance à vol d'oiseau × détour moyen, à 45 km/h
            $r = ['provider' => 'estimation', 'traffic' => false, 'raw_s' => $distDest * 1.35 / 12.5,
                'dist_m' => $distDest * 1.35, 'delay_s' => 0.0, 'coords' => [[$lon, $lat], [$destLon, $destLat]]];
        }
        $f += [
            'route_json' => json_encode($r['coords']),
            'route_v' => (int)$iv['route_v'] + 1,
            'route_at' => $now,
            'route_raw_s' => $r['raw_s'],
            'route_dist_m' => $r['dist_m'],
            'route_provider' => $r['provider'],
            'route_traffic' => $r['traffic'] ? 1 : 0,
        ];
        // référence de mesure : prise au début du mouvement, avec le même fournisseur
        $hist = $iv['route_hist'] ? (json_decode($iv['route_hist'], true) ?: []) : [];
        if ($iv['move_started_at'] && (!$iv['base_raw_s'] || $iv['base_provider'] !== $r['provider'])) {
            $f['base_raw_s'] = $r['raw_s'];
            $f['base_at'] = min($now, $ts);
            $f['base_provider'] = $r['provider'];
            $hist = [];
        }
        // historique (heure de la position, durée restante « théorique ») pour la correction glissante
        if ($iv['move_started_at']) {
            $hist[] = [min($now, $ts), round($r['raw_s'], 1)];
            $f['route_hist'] = json_encode(array_slice($hist, -80));
        }
        $merged = array_merge($iv, $f);
        $f += compute_eta($merged, $now, $distDest);
    }

    update_iv($id, $f);
    return get_iv($id);
}

/**
 * Traite un lot de positions (envoyées en rafale après une zone sans réseau).
 * Toutes les positions sont enregistrées dans l'ordre ; l'itinéraire n'est recalculé que sur la plus récente.
 */
function ingest_points(array $iv, array $points, string $source): array
{
    $clean = [];
    foreach ($points as $p) {
        if (!is_array($p) || !isset($p['lat'], $p['lon']) || !is_numeric($p['lat']) || !is_numeric($p['lon'])) continue;
        $n = fn($k) => isset($p[$k]) && is_numeric($p[$k]) ? (float)$p[$k] : null;
        $speed = $n('speed');
        $heading = $n('heading');
        $clean[] = [
            'lat' => (float)$p['lat'], 'lon' => (float)$p['lon'], 'acc' => $n('acc'),
            'speed' => ($speed !== null && $speed >= 0) ? $speed : null,
            'heading' => ($heading !== null && $heading >= 0 && $heading <= 360) ? $heading : null,
            'ts' => isset($p['ts']) && is_numeric($p['ts']) ? (int)round((float)$p['ts']) : now_ts(),
        ];
    }
    usort($clean, fn($a, $b) => $a['ts'] <=> $b['ts']);
    $clean = array_slice($clean, -300);
    $last = count($clean) - 1;
    foreach ($clean as $i => $p) {
        if ($iv['status'] !== 'enroute') break;
        $iv = process_position($iv, $p['lat'], $p['lon'], $p['acc'], $p['speed'], $p['heading'], $p['ts'], $source, $i === $last);
    }
    return $iv;
}

/**
 * Vitesse réellement constatée sur les dernières minutes (m/s) à partir des positions GPS.
 * Retourne [vitesse, durée de la fenêtre en s] ou null.
 */
function recent_speed(int $ivId, int $now, int $window = 240): ?array
{
    $st = db()->prepare('SELECT lat, lon, ts FROM positions WHERE iv_id = ? AND ts >= ? ORDER BY ts');
    $st->execute([$ivId, $now - $window]);
    $rows = $st->fetchAll();
    if (count($rows) < 3) return null;
    $d = 0.0;
    for ($i = 1, $n = count($rows); $i < $n; $i++) {
        $d += haversine((float)$rows[$i - 1]['lat'], (float)$rows[$i - 1]['lon'], (float)$rows[$i]['lat'], (float)$rows[$i]['lon']);
    }
    $span = (int)$rows[count($rows) - 1]['ts'] - (int)$rows[0]['ts'];
    // si la dernière position date un peu (réseau coupé), on compte le temps écoulé depuis
    $span = max($span, min($window, $now - (int)$rows[0]['ts']));
    return $span >= 90 ? [$d / $span, $span] : null;
}

/** Depuis combien de secondes roule-t-on nettement sous la vitesse prévue ? (tranches de 60 s, 20 min max) */
function slow_duration(int $ivId, int $now, float $vExp): int
{
    $st = db()->prepare('SELECT lat, lon, ts FROM positions WHERE iv_id = ? AND ts >= ? ORDER BY ts');
    $st->execute([$ivId, $now - 1200]);
    $rows = $st->fetchAll();
    $slow = 0;
    for ($end = $now; $end > $now - 1200; $end -= 60) {
        $b = array_values(array_filter($rows, fn($r) => $r['ts'] > $end - 60 && $r['ts'] <= $end));
        if (count($b) < 2) {
            if ($slow > 0) $slow += 60; // pas de point (arrêt complet, iPhone silencieux) : on continue le compte
            else break;
            continue;
        }
        $d = haversine((float)$b[0]['lat'], (float)$b[0]['lon'], (float)$b[count($b) - 1]['lat'], (float)$b[count($b) - 1]['lon']);
        $span = max(1, (int)$b[count($b) - 1]['ts'] - (int)$b[0]['ts']);
        if ($d / $span < 0.6 * $vExp) $slow += 60; else break;
    }
    return $slow;
}

/** Calcule l'heure d'arrivée à partir de l'itinéraire courant et de la progression observée. */
function compute_eta(array $iv, int $now, float $distDest): array
{
    $raw = (float)$iv['route_raw_s'];
    $traffic = (bool)$iv['route_traffic'];

    // a priori : trafic temps réel (TomTom) ou modèle heure de pointe × coefficient appris
    $prior = $traffic ? learned_factor(true) : learned_factor(false) * tod_factor($now);

    // correction terrain sur une fenêtre glissante de 7 min : temps réellement écoulé
    // vs. portion d'itinéraire « théorique » parcourue. Un ralentissement passé finit par sortir de la fenêtre.
    $w = 0.0;
    $obs = $prior;
    $hist = $iv['route_hist'] ? (json_decode($iv['route_hist'], true) ?: []) : [];
    if ($hist && $iv['base_provider'] === $iv['route_provider']) {
        $ref = null;
        foreach ($hist as $hRow) {
            if ($hRow[0] >= $now - 420) { $ref = $hRow; break; }
        }
        $ref ??= end($hist);
        $covered = (float)$ref[1] - $raw;   // secondes « théoriques » parcourues
        $elapsed = $now - (int)$ref[0];      // secondes réelles
        if ($covered > 60 && $elapsed > 60) {
            $obs = max(0.6, min(2.5, $elapsed / $covered));
            $w = max(0.0, min(0.7, $covered / 600));
        } elseif ($elapsed > 240 && $covered < 60) {
            $obs = 2.0; // quasi à l'arrêt depuis 4 min
            $w = 0.4;
        }
    }
    $factor = $w * $obs + (1 - $w) * $prior;
    $remaining = $raw * $factor;

    // Bouchon / accident détecté grâce à la vitesse GPS réelle : si l'on roule nettement moins vite
    // que prévu depuis plusieurs minutes, on estime combien de temps le ralentissement va encore durer
    // (≈ 80 % du temps déjà passé au ralenti, entre 2 et 10 min), puis circulation normale.
    $jam = false;
    $routeDist = (float)$iv['route_dist_m'];
    $vExp = ($raw > 0 && $routeDist > 0) ? $routeDist / $raw : 0;
    if ($iv['move_started_at'] && $vExp > 0 && $routeDist > 1500 && ($now - (int)$iv['move_started_at']) > 180) {
        $rs = recent_speed((int)$iv['id'], $now, 150);
        $slowFor = ($rs && $vExp / max($rs[0], 0.5) > 1.6) ? slow_duration((int)$iv['id'], $now, $vExp) : 0;
        if ($slowFor >= 120) {
            $vRecent = $rs[0];
            $tJam = max(120, min(600, 0.8 * $slowFor));
            $jamDist = min($vRecent * $tJam, $routeDist - 300);
            $restRaw = max(0, $raw - $jamDist / $vExp);
            $remaining = $tJam + $restRaw * $prior;
            $jam = true;
        }
    }
    $remaining += ($distDest > 300 ? parking_buffer_s() : 0);
    $remaining = max(30, $remaining);
    $target = $now + (int)round($remaining);

    // lissage pour éviter que l'heure saute à chaque recalcul (sauf gros changement)
    $prev = $iv['eta_at'] ? (int)$iv['eta_at'] : null;
    $eta = ($prev && abs($target - $prev) < 600) ? (int)round($prev + 0.65 * ($target - $prev)) : $target;
    $eta = max($now + 30, $eta);
    $rem = $eta - $now;

    // fourchette d'incertitude (se resserre avec les observations)
    $u = ($traffic ? 0.10 : 0.18) * (1 - $w) + 0.06 + ($jam ? 0.12 : 0);
    $low = $now + (int)round($rem * (1 - $u * 0.6));
    $high = $now + (int)round($rem * (1 + $u));

    $out = ['eta_at' => $eta, 'eta_low' => $low, 'eta_high' => $high, 'eta_factor' => round($raw > 0 ? ($remaining - ($distDest > 300 ? parking_buffer_s() : 0)) / $raw : $factor, 3), 'eta_updated' => $now, 'eta_jam' => $jam ? 1 : 0];
    if (!$iv['first_eta_at']) $out['first_eta_at'] = $eta;
    return $out;
}

function mark_arrived(array $iv): array
{
    $now = now_ts();
    // apprentissage : écart réel / prévu sur ce trajet (trajets de plus de 5 min uniquement)
    if ($iv['base_raw_s'] && $iv['base_at'] && (float)$iv['base_raw_s'] > 300 && $iv['base_provider'] !== 'estimation') {
        $traffic = $iv['base_provider'] === 'tomtom';
        $predicted = (float)$iv['base_raw_s'] * ($traffic ? 1.0 : tod_factor((int)$iv['base_at']));
        $actual = $now - (int)$iv['base_at'];
        $ratio = max(0.7, min(1.8, $actual / max(60, $predicted)));
        $key = $traffic ? 'learn_tt' : 'learn_osrm';
        $old = learned_factor($traffic);
        set_setting($key, (string)round(max(0.85, min(1.5, 0.8 * $old + 0.2 * $ratio)), 4));
        set_setting($key . '_n', (string)((int)setting($key . '_n', 0) + 1));
    }
    update_iv((int)$iv['id'], [
        'status' => 'arrived', 'arrived_at' => $now, 'near_count' => 0,
        'eta_at' => null, 'eta_low' => null, 'eta_high' => null,
    ]);
    return get_iv((int)$iv['id']);
}

function bearing(float $lat1, float $lon1, float $lat2, float $lon2): float
{
    $p1 = deg2rad($lat1);
    $p2 = deg2rad($lat2);
    $dl = deg2rad($lon2 - $lon1);
    $y = sin($dl) * cos($p2);
    $x = cos($p1) * sin($p2) - sin($p1) * cos($p2) * cos($dl);
    return fmod(rad2deg(atan2($y, $x)) + 360, 360);
}

/** Données publiques pour la page client (avec zone de confidentialité autour du domicile). */
function public_state(array $iv, int $knownRouteV = -1): array
{
    $now = now_ts();
    $st = $iv['status'];
    $out = [
        'status' => $st,
        'label' => STATUS_LABELS[$st] ?? $st,
        'now' => $now,
        'scheduled_at' => (int)$iv['scheduled_at'],
        'slot_end' => iv_slot_end($iv),
        'dest' => ['lat' => (float)$iv['lat'], 'lon' => (float)$iv['lon']],
        'trip_started_at' => $iv['trip_started_at'] ? (int)$iv['trip_started_at'] : null,
        'arrived_at' => $iv['arrived_at'] ? (int)$iv['arrived_at'] : null,
        'done_at' => $iv['done_at'] ? (int)$iv['done_at'] : null,
        'pos' => null,
        'hidden' => false,
        'eta' => null,
        'route_v' => (int)$iv['route_v'],
    ];
    if ($st === 'done' && $iv['done_at'] && $now - (int)$iv['done_at'] > 48 * 3600) {
        $out['expired'] = true;
        return $out;
    }
    if ($st !== 'enroute') return $out;

    $homeLat = setting('home_lat');
    $homeLon = setting('home_lon');
    $radius = (int)setting('privacy_m', 800);
    $inZone = function (float $la, float $lo) use ($homeLat, $homeLon, $radius): bool {
        return $homeLat !== null && $homeLat !== '' && $radius > 0
            && haversine($la, $lo, (float)$homeLat, (float)$homeLon) < $radius;
    };

    if ($iv['pos_lat'] !== null) {
        $la = (float)$iv['pos_lat'];
        $lo = (float)$iv['pos_lon'];
        if ($inZone($la, $lo)) {
            $out['hidden'] = true;
        } else {
            $out['pos'] = [
                'lat' => round($la, 6), 'lon' => round($lo, 6),
                'heading' => $iv['pos_heading'] !== null ? round((float)$iv['pos_heading']) : null,
                'speed' => $iv['pos_speed'] !== null ? round((float)$iv['pos_speed'], 1) : null,
                'ts' => (int)$iv['pos_ts'],
            ];
        }
        $out['stale'] = ($now - (int)$iv['pos_ts']) > 120;
        $out['last_seen'] = (int)$iv['pos_ts'];
    }
    if ($iv['eta_at']) {
        $out['eta'] = [
            'at' => (int)$iv['eta_at'], 'low' => (int)$iv['eta_low'], 'high' => (int)$iv['eta_high'],
            'traffic' => (bool)$iv['route_traffic'], 'dist_m' => (int)round((float)$iv['route_dist_m']),
            'jam' => (bool)($iv['eta_jam'] ?? 0),
            'updated' => (int)$iv['eta_updated'],
        ];
    }
    if ($knownRouteV !== (int)$iv['route_v'] && $iv['route_json']) {
        $coords = json_decode($iv['route_json'], true) ?: [];
        // on retire la partie du tracé proche du domicile
        $coords = array_values(array_filter($coords, fn($c) => !$inZone((float)$c[1], (float)$c[0])));
        $out['route'] = $coords;
    }
    return $out;
}
