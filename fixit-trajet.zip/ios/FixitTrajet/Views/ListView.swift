import SwiftUI
import UIKit
import CoreLocation

private struct DayGroup: Identifiable {
    let id: String
    let items: [Intervention]
}

struct ListView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var trips: TripManager
    @EnvironmentObject var reminders: ReminderCenter
    @State private var items: [Intervention] = []
    @State private var loading = false
    @State private var error: String?
    @State private var selected: Intervention?
    @State private var showSettings = false
    @AppStorage("appearance") private var appearance = "auto"

    var body: some View {
        NavigationStack {
            List {
                if let error {
                    Section { Label(error, systemImage: "wifi.exclamationmark").foregroundStyle(.orange) }
                }
                if trips.authorization != .authorizedAlways {
                    Section {
                        Button {
                            if trips.authorization == .denied || trips.authorization == .restricted {
                                if let u = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(u) }
                            } else {
                                trips.requestPermission()
                            }
                        } label: {
                            Label("Autoriser la position « Toujours » pour un suivi écran verrouillé", systemImage: "location.circle")
                        }
                    }
                }
                if !reminders.due.isEmpty {
                    Section {
                        ForEach(reminders.due) { r in
                            Button { reminders.composing = r } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: "bell.badge.fill").foregroundStyle(Brand.blue).font(.title3)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(r.client).font(.headline)
                                        Text(r.label).font(.subheadline).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Text("Envoyer").font(.subheadline.bold()).foregroundStyle(Brand.blueDark)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    } header: {
                        Text("Rappels SMS à envoyer")
                    } footer: {
                        Text("Le texte est déjà prêt : touchez, vérifiez, puis « Envoyer ».")
                    }
                }
                if let info = reminders.info {
                    Section { Label(info, systemImage: "checkmark.circle.fill").foregroundStyle(Brand.ok) }
                }
                ForEach(groups) { group in
                    Section(group.id) {
                        ForEach(group.items) { iv in
                            Button { selected = iv } label: { Row(iv: iv) }
                                .buttonStyle(.plain)
                        }
                    }
                }
                if items.isEmpty && !loading && error == nil {
                    Section {
                        Text("Aucune intervention prévue. Créez-les depuis l'espace admin du site.")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Interventions")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Picker("Apparence", selection: $appearance) {
                            Label("Automatique", systemImage: "circle.lefthalf.filled").tag("auto")
                            Label("Clair", systemImage: "sun.max").tag("light")
                            Label("Sombre", systemImage: "moon").tag("dark")
                        }
                        Divider()
                        Button(role: .destructive) { showSettings = true } label: {
                            Label("Déconnecter cet iPhone", systemImage: "rectangle.portrait.and.arrow.right")
                        }
                    } label: { Image(systemName: "gearshape") }
                }
            }
            .refreshable { await load() }
            .task {
                await load()
                await reminders.requestPermission()
            }
            .sheet(item: $selected) { iv in
                DetailSheet(iv: iv) { selected = nil }
                    .presentationDetents([.medium, .large])
            }
            .confirmationDialog("Déconnecter cet iPhone ?", isPresented: $showSettings, titleVisibility: .visible) {
                Button("Déconnecter cet iPhone", role: .destructive) { config.reset() }
            } message: {
                Text("Connecté à \(config.server)")
            }
        }
    }

    private var groups: [DayGroup] {
        let active = items.filter { ["enroute", "arrived", "working"].contains($0.status) }
        let planned = items.filter { $0.status == "planned" }
        var out: [DayGroup] = []
        if !active.isEmpty { out.append(DayGroup(id: "En cours", items: active)) }
        let byDay = Dictionary(grouping: planned) { Fmt.day($0.scheduledDate) }
        let keys = byDay.keys.sorted { (byDay[$0]?.first?.scheduledAt ?? 0) < (byDay[$1]?.first?.scheduledAt ?? 0) }
        for key in keys {
            out.append(DayGroup(id: key, items: byDay[key] ?? []))
        }
        return out
    }

    private func load() async {
        guard let api = config.client else { return }
        loading = true
        defer { loading = false }
        do {
            items = try await api.list()
            error = nil
            await reminders.sync(api)
        } catch let e {
            error = e.localizedDescription
        }
    }
}

private struct Row: View {
    let iv: Intervention
    var body: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 0) {
                Text(Fmt.clock(iv.scheduledAt))
                    .font(.system(.title3, design: .rounded).bold())
                if let e = iv.slotEnd, e > iv.scheduledAt {
                    Text("→ \(Fmt.clock(e))").font(.caption.bold()).foregroundStyle(.secondary)
                }
            }
            .frame(width: 64, alignment: .leading)
            VStack(alignment: .leading, spacing: 2) {
                Text(iv.client).font(.headline)
                Text(iv.address).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer()
            if iv.status != "planned" {
                Text(iv.statusLabel).font(.caption.bold())
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(Brand.blue.opacity(0.12), in: Capsule())
                    .foregroundStyle(Brand.blueDark)
            }
        }
        .contentShape(Rectangle())
        .padding(.vertical, 4)
    }
}

private struct DetailSheet: View {
    let iv: Intervention
    let dismiss: () -> Void
    @EnvironmentObject var trips: TripManager

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text("\(Fmt.day(iv.scheduledDate)) · \(Fmt.slot(iv))").font(.subheadline.bold()).foregroundStyle(Brand.blueDark)
                Text(iv.client).font(.title.bold())
                Text(iv.address).foregroundStyle(.secondary)
                if !iv.addressExtra.isEmpty { Text(iv.addressExtra).font(.footnote).foregroundStyle(.secondary) }
            }
            Button {
                Task {
                    await trips.start(iv)
                    if trips.trip != nil { dismiss() }
                }
            } label: {
                HStack {
                    Spacer()
                    if trips.busy { ProgressView().tint(.white) } else { Label("Je pars", systemImage: "car.fill").font(.title3.bold()) }
                    Spacer()
                }
                .padding(.vertical, 16)
                .background(Brand.blue, in: RoundedRectangle(cornerRadius: 14))
                .foregroundStyle(.white)
            }
            .disabled(trips.busy)
            if let m = trips.message { Text(m).font(.footnote).foregroundStyle(.red) }
            HStack {
                if !iv.phone.isEmpty, let tel = URL(string: "tel:+\(iv.phone)") {
                    Link(destination: tel) { Label("Appeler", systemImage: "phone.fill") }
                        .buttonStyle(.bordered)
                }
                ShareLink(item: iv.link) { Label("Lien client", systemImage: "square.and.arrow.up") }
                    .buttonStyle(.bordered)
            }
            Text("Le client voit votre position uniquement pendant ce trajet. Elle n'est plus partagée dès votre arrivée.")
                .font(.footnote).foregroundStyle(.secondary)
            Spacer()
        }
        .padding(22)
    }
}
