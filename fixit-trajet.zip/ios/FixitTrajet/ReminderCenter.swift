import Foundation
import SwiftUI
import UIKit
import MessageUI
import UserNotifications
import BackgroundTasks

/// Rappel SMS avant intervention, tel que renvoyé par api/app.php (action "reminders").
struct Reminder: Codable, Hashable, Identifiable {
    let ivId: Int
    let rule: String
    let sched: Int
    let due: Int
    let state: String
    let label: String
    let client: String
    let phone: String
    let text: String

    enum CodingKeys: String, CodingKey {
        case ivId = "id", rule, sched, due, state, label, client, phone, text
    }

    var id: String { "rem-\(ivId)-\(rule)-\(sched)" }
    var dueDate: Date { Date(timeIntervalSince1970: TimeInterval(due)) }
}

struct RemindersResponse: Codable {
    let items: [Reminder]
}

/// Notifications de rappel + envoi du SMS en un geste (le texte est prêt, il suffit de toucher « Envoyer »).
@MainActor
final class ReminderCenter: NSObject, ObservableObject {
    nonisolated static let refreshID = "fr.fixit-service.trajet.refresh"
    private nonisolated static let notifiedKey = "notifiedReminders"

    @Published private(set) var due: [Reminder] = []
    @Published private(set) var upcoming: [Reminder] = []
    @Published var composing: Reminder?
    @Published var info: String?
    private var pendingOpen: String?

    override init() {
        super.init()
        UNUserNotificationCenter.current().delegate = self
    }

    func requestPermission() async {
        let c = UNUserNotificationCenter.current()
        if await c.notificationSettings().authorizationStatus == .notDetermined {
            _ = try? await c.requestAuthorization(options: [.alert, .sound])
        }
    }

    func sync(_ api: APIClient?) async {
        guard let api, let items = try? await api.reminders() else { return }
        apply(items)
        await Self.schedule(items)
    }

    private func apply(_ items: [Reminder]) {
        let now = Int(Date().timeIntervalSince1970)
        due = items.filter { $0.due <= now }
        upcoming = items.filter { $0.due > now }
        if let p = pendingOpen, let r = items.first(where: { $0.id == p }) {
            pendingOpen = nil
            composing = r
        }
    }

    func open(_ key: String) {
        if let r = (due + upcoming).first(where: { $0.id == key }) { composing = r } else { pendingOpen = key }
    }

    /// Appelé quand le SMS a été envoyé depuis la feuille de rédaction.
    func markSent(_ r: Reminder, api: APIClient?) async {
        due.removeAll { $0.id == r.id }
        upcoming.removeAll { $0.id == r.id }
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [r.id])
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [r.id])
        do {
            try await api?.reminderSent(ivId: r.ivId, rule: r.rule, sched: r.sched)
            info = "Rappel envoyé à \(r.client)."
        } catch {
            info = "SMS envoyé, mais le site n'a pas pu être prévenu (réseau)."
        }
    }

    // MARK: Notifications programmées

    /// Programme une notification à l'heure de chaque rappel ; prévient tout de suite pour ceux déjà à envoyer.
    nonisolated static func schedule(_ items: [Reminder]) async {
        let c = UNUserNotificationCenter.current()
        let pending = await c.pendingNotificationRequests().map(\.identifier).filter { $0.hasPrefix("rem-") }
        c.removePendingNotificationRequests(withIdentifiers: pending)
        var notified = Set(UserDefaults.standard.stringArray(forKey: notifiedKey) ?? [])
        notified.formIntersection(items.map(\.id))
        let now = Date()
        for r in items {
            let content = UNMutableNotificationContent()
            content.title = "Rappel SMS à envoyer"
            content.body = "\(r.client) · \(r.label). Touchez pour l'envoyer."
            content.sound = .default
            content.threadIdentifier = "rappels"
            content.userInfo = ["key": r.id]
            var trigger: UNNotificationTrigger?
            if r.dueDate > now {
                let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: r.dueDate)
                trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
            } else if notified.contains(r.id) {
                continue                      // déjà signalé : visible dans l'app
            }
            try? await c.add(UNNotificationRequest(identifier: r.id, content: content, trigger: trigger))
            notified.insert(r.id)
        }
        UserDefaults.standard.set(Array(notified), forKey: notifiedKey)
    }

    // MARK: Actualisation en arrière-plan (iOS choisit le moment, en général plusieurs fois par jour)

    nonisolated static func scheduleRefresh() {
        let req = BGAppRefreshTaskRequest(identifier: refreshID)
        req.earliestBeginDate = Date(timeIntervalSinceNow: 45 * 60)
        try? BGTaskScheduler.shared.submit(req)
    }

    nonisolated static func backgroundSync() async {
        scheduleRefresh()
        guard let api = await MainActor.run(body: { AppConfig.storedClient() }),
              let items = try? await api.reminders() else { return }
        await schedule(items)
    }
}

extension ReminderCenter: UNUserNotificationCenterDelegate {
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification) async -> UNNotificationPresentationOptions {
        [.banner, .list, .sound]
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse) async {
        guard let key = response.notification.request.content.userInfo["key"] as? String else { return }
        await MainActor.run { self.open(key) }
    }
}

/// Feuille d'envoi du SMS (Messages) avec destinataire et texte déjà remplis.
struct MessageComposer: UIViewControllerRepresentable {
    let reminder: Reminder
    let done: (Bool) -> Void

    static var available: Bool { MFMessageComposeViewController.canSendText() }

    func makeCoordinator() -> Coordinator { Coordinator(done: done) }

    func makeUIViewController(context: Context) -> MFMessageComposeViewController {
        let vc = MFMessageComposeViewController()
        vc.recipients = [reminder.phone]
        vc.body = reminder.text
        vc.messageComposeDelegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ vc: MFMessageComposeViewController, context: Context) {}

    final class Coordinator: NSObject, MFMessageComposeViewControllerDelegate {
        let done: (Bool) -> Void
        init(done: @escaping (Bool) -> Void) { self.done = done }
        func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
            done(result == .sent)
        }
    }
}

/// Aperçu du rappel avant envoi (utilisé quand Messages n'est pas disponible, ex. simulateur).
struct ReminderSheet: View {
    let reminder: Reminder
    @EnvironmentObject var reminders: ReminderCenter
    @EnvironmentObject var config: AppConfig
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        if MessageComposer.available {
            MessageComposer(reminder: reminder) { sent in
                dismiss()
                if sent { Task { await reminders.markSent(reminder, api: config.client) } }
            }
            .ignoresSafeArea()
        } else {
            NavigationStack {
                Form {
                    Section("À \(reminder.client) · \(reminder.phone)") { Text(reminder.text) }
                    Section {
                        Button("Ouvrir Messages") {
                            let body = reminder.text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                            if let u = URL(string: "sms:\(reminder.phone)&body=\(body)") { UIApplication.shared.open(u) }
                        }
                        Button("Marquer comme envoyé") {
                            dismiss()
                            Task { await reminders.markSent(reminder, api: config.client) }
                        }
                    }
                }
                .navigationTitle(reminder.label)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Fermer") { dismiss() } } }
            }
        }
    }
}
