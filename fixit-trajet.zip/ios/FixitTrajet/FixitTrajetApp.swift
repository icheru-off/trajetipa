import SwiftUI
import UIKit

@main
struct FixitTrajetApp: App {
    @StateObject private var config = AppConfig()
    @StateObject private var trips = TripManager()
    @StateObject private var reminders = ReminderCenter()
    @Environment(\.scenePhase) private var phase
    @State private var setupError: String?
    @AppStorage("appearance") private var appearance = "auto"   // auto · light · dark

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(config)
                .environmentObject(trips)
                .environmentObject(reminders)
                .sheet(item: $reminders.composing) { r in
                    ReminderSheet(reminder: r)
                        .environmentObject(reminders)
                        .environmentObject(config)
                }
                .tint(Brand.blue)
                .preferredColorScheme(appearance == "dark" ? .dark : appearance == "light" ? .light : nil)
                .onAppear {
                    trips.attach(config)
                    Task { await trips.resumeIfNeeded() }
                }
                .onOpenURL { url in
                    Task {
                        setupError = await config.handle(url: url)
                        trips.attach(config)
                    }
                }
                .alert("Configuration", isPresented: Binding(get: { setupError != nil }, set: { if !$0 { setupError = nil } })) {
                    Button("OK", role: .cancel) {}
                } message: {
                    Text(setupError ?? "")
                }
        }
        .onChange(of: phase) { p in
            if p == .active {
                Task {
                    await trips.flush(force: true)
                    await reminders.sync(config.client)
                }
            }
            if p == .background { ReminderCenter.scheduleRefresh() }
        }
        .backgroundTask(.appRefresh(ReminderCenter.refreshID)) {
            await ReminderCenter.backgroundSync()
        }
    }
}

/// Couleurs FixIT, adaptées automatiquement au mode clair / sombre.
enum Brand {
    static let blue = Color(light: 0x1489C4, dark: 0x29ABE2)
    static let blueDark = Color(light: 0x0C6D9E, dark: 0x8BD9F7)   // texte bleu lisible sur fond sombre
    static let paper = Color(light: 0xF6F4EF, dark: 0x0E1112)      // fond
    static let card = Color(light: 0xFFFFFF, dark: 0x1C2124)       // cartes et boutons secondaires
    static let ink = Color(light: 0x111412, dark: 0xECEFEC)
    static let ok = Color(light: 0x1E7F4F, dark: 0x2FA36A)
    static let uiBlue = UIColor.dynamic(light: 0x1489C4, dark: 0x29ABE2)
    static let uiMarker = UIColor.dynamic(light: 0x111412, dark: 0x29ABE2)
}

extension UIColor {
    convenience init(hex: UInt32) {
        self.init(red: CGFloat((hex >> 16) & 0xFF) / 255, green: CGFloat((hex >> 8) & 0xFF) / 255,
                  blue: CGFloat(hex & 0xFF) / 255, alpha: 1)
    }
    static func dynamic(light: UInt32, dark: UInt32) -> UIColor {
        UIColor { $0.userInterfaceStyle == .dark ? UIColor(hex: dark) : UIColor(hex: light) }
    }
}

extension Color {
    init(light: UInt32, dark: UInt32) { self.init(uiColor: UIColor.dynamic(light: light, dark: dark)) }
}
