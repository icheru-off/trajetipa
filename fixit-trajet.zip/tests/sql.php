<?php
$f = glob(__DIR__ . '/../site/data/*.sqlite')[0];
$pdo = new PDO('sqlite:' . $f);
$st = $pdo->query($argv[1]);
foreach ($st ? $st->fetchAll(PDO::FETCH_NUM) : [] as $r) echo implode('|', $r), "\n";
