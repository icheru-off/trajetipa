// v3 : rappels SMS avant intervention (règles personnalisables, tableau de bord, fiche, API Raccourcis / app)
const { chromium } = require('/home/claude/node_modules/playwright-core');
const { execSync } = require('child_process');
const BASE = 'http://127.0.0.1:8088';
const OUT = '/home/claude/suivi-test/shots';
const sql = (q) => execSync('php /home/claude/suivi-test/sql.php ' + JSON.stringify(q)).toString().trim();
const ok = (c, m) => { console.log((c ? '✅ ' : '❌ ') + m); if (!c) process.exitCode = 1; };
const errors = [];
const pad = (n) => String(n).padStart(2, '0');
const hm = (d) => { d = new Date(Math.ceil(d.getTime() / 300e3) * 300e3); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
const ymd = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());

async function create(page, { name, phone, date, time }) {
  await page.goto(BASE + '/admin/edit.php');
  if (name) await page.fill('input[name=client_name]', name);
  if (phone) await page.fill('input[name=client_phone]', phone);
  await page.fill('input[name=address]', '2 Avenue Thiers 77000 Melun');
  await page.evaluate(() => { document.querySelector('[name=lat]').value = '48.5326'; document.querySelector('[name=lon]').value = '2.6560'; document.querySelector('[name=ac_ok]').value = '1'; });
  await page.fill('input[name=date]', date);
  await page.fill('input[name=time]', time);
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);
  return +page.url().match(/id=(\d+)/)[1];
}
async function api(body) {
  const key = sql("SELECT v FROM settings WHERE k='app_key'");
  const r = await fetch(BASE + '/api/app.php', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-App-Key': key }, body: JSON.stringify(body) });
  return r.json();
}

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome' });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('dialog', (d) => d.accept());

  const before = sql("SELECT v FROM settings WHERE k='schema'");
  await page.goto(BASE + '/admin/login.php');
  ok(sql("SELECT v FROM settings WHERE k='schema'") === '3' && sql("SELECT name FROM sqlite_master WHERE name='reminder_log'") === 'reminder_log', 'Base v2 migrée en v3 (table des rappels créée)');
  await page.fill('input[name=password]', 'MotDePasseTest123');
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);

  // 1. Réglages : règle 1 = veille 18h (par défaut), règle 2 = 2 h avant (activée), texte personnalisé
  await page.goto(BASE + '/admin/settings.php#rappels');
  const r = (i) => page.locator('[data-rule-box]').nth(i);
  ok(await r(0).locator('[data-rule-on]').isChecked() && await r(0).locator('[data-rule-when]').inputValue() === 'd1', 'Par défaut : rappel la veille, activé');
  ok((await r(0).locator('[data-rule-preview]').textContent()).startsWith('Bonjour Mme Martin, petit rappel : je passe chez vous demain entre 14h00 et 14h30'), 'Aperçu en direct : « ' + (await r(0).locator('[data-rule-preview]').textContent()).slice(0, 80) + '… »');
  await r(1).locator('.switch').click();
  await r(1).locator('[data-rule-when]').selectOption('m');
  ok(await r(1).locator('[data-rule-at]').isHidden() && await r(1).locator('[data-rule-min]').isVisible(), '« Quelques heures avant » : choix du délai au lieu de l\'heure');
  await r(1).locator('[data-rule-min]').selectOption('120');
  await r(1).locator('[data-rule-text]').fill('{bonjour}, je passe {quand} {creneau}. Suivi : {lien}');
  await r(1).locator('[data-rule-text]').focus();
  await page.locator('details.vars summary').click();
  await page.locator('[data-var="{telephone}"]').click();
  ok((await r(1).locator('[data-rule-text]').inputValue()).endsWith('{telephone}'), 'Bouton {telephone} : mot inséré dans le texte');
  ok(/^[0-9]+ caractères/.test(await r(1).locator('[data-rule-count]').textContent()), 'Compteur : ' + await r(1).locator('[data-rule-count]').textContent());
  await page.locator('#rappels').screenshot({ path: OUT + '/v3-01-reglages-rappels.png' });
  await Promise.all([page.waitForNavigation(), page.locator('#rappels button[type=submit]').click()]);
  const rules = JSON.parse(sql("SELECT v FROM settings WHERE k='reminder_rules'"));
  ok(rules[0].on && rules[0].days === 1 && rules[0].at === '18:00' && rules[1].on && rules[1].kind === 'minutes' && rules[1].minutes === 120, 'Règles enregistrées (veille 18h + 2 h avant)');

  // 2. Intervention demain → rappel veille prévu à 18h, pas encore dû
  const tmr = new Date(Date.now() + 86400e3);
  const idA = await create(page, { name: 'Mme Durand', phone: '06 12 34 56 78', date: ymd(tmr), time: '14:00' });
  const cardA = (await page.textContent('#rappels')).replace(/\s+/g, ' ');
  ok(/La veille à 18h00/.test(cardA) && /2 h avant le rendez-vous/.test(cardA), 'Fiche : 2 rappels listés (veille 18h, 2 h avant)');
  const now = new Date();
  ok(now.getHours() >= 18 ? /À envoyer maintenant/.test(cardA) : /Prévu aujourd'hui à 18h00/.test(cardA), 'Rappel veille : ' + (now.getHours() >= 18 ? 'à envoyer maintenant' : 'prévu aujourd\'hui à 18h00'));
  const txtA = await page.locator('#rappels [data-rule=r1] textarea').inputValue();
  ok(txtA.startsWith('Bonjour Mme Durand, petit rappel : je passe chez vous demain vers 14h00'), 'Texte du rappel veille : « ' + txtA.split('\n')[0] + ' »');

  // 3. Intervention dans 1 h 30 (prise hier) → rappel « 2 h avant » à envoyer maintenant
  const soon = new Date(Date.now() + 90 * 60e3);
  const idB = await create(page, { name: '', phone: '07 98 76 54 32', date: ymd(soon), time: hm(soon) });
  sql('UPDATE interventions SET created_at = created_at - 86400 WHERE id = ' + idB);
  const due = await api({ action: 'reminders_due' });
  const itB = due.items.find((x) => x.id === idB && x.rule === 'r2');
  ok(itB && itB.phone === '+33798765432' && itB.text.startsWith('Bonjour, je passe aujourd\'hui vers ') && itB.text.endsWith('06 15 51 73 81'), 'API Raccourcis (reminders_due) : ' + (itB ? JSON.stringify({ phone: itB.phone, text: itB.text.slice(0, 60) + '…' }) : 'absent'));
  ok(!due.items.some((x) => x.id === idA), 'Rappel non encore dû absent de la liste automatique');

  // 4. Tableau de bord : carte « Rappels SMS à envoyer »
  await page.goto(BASE + '/admin/');
  const dash = page.locator('[data-rem][data-iv="' + idB + '"]');
  ok(await dash.count() === 1, 'Tableau de bord : carte du rappel à envoyer');
  await page.screenshot({ path: OUT + '/v3-02-tableau-de-bord.png', fullPage: false });
  await dash.locator('[data-rem-act=mark]').click();
  await page.waitForFunction((id) => document.querySelector('[data-rem][data-iv="' + id + '"] [data-rem-state]').textContent.includes('Envoyé'), idB);
  ok(sql("SELECT via FROM reminder_log WHERE iv_id=" + idB) === 'manuel', '« Déjà envoyé » : enregistré');
  ok(!(await api({ action: 'reminders_due' })).items.some((x) => x.id === idB), 'Plus de doublon : rappel retiré de la liste automatique');
  await dash.locator('[data-rem-act=undo]').click();
  await page.waitForFunction((id) => !document.querySelector('[data-rem][data-iv="' + id + '"] [data-rem-state]').textContent.includes('Envoyé'), idB);
  ok(sql("SELECT count(*) FROM reminder_log WHERE iv_id=" + idB) === '0', '« Annuler envoyé » fonctionne');
  const sent = await api({ action: 'reminder_sent', id: idB, rule: 'r2', sched: itB.sched });
  ok(sent.ok && sql("SELECT via FROM reminder_log WHERE iv_id=" + idB) === 'auto', 'API reminder_sent (Raccourcis) : enregistré comme automatique');
  await page.goto(BASE + '/admin/view.php?id=' + idB);
  ok(/Envoyé .*automatique/.test(await page.textContent('#rappels [data-rule=r2] [data-rem-state]')), 'Fiche : « ✓ Envoyé … (automatique) »');

  // 5. Déplacer le rendez-vous → nouveau rappel à envoyer
  const later = new Date(soon.getTime() + 30 * 60e3);
  await page.goto(BASE + '/admin/edit.php?id=' + idB);
  await page.fill('input[name=time]', hm(later));
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);
  ok((await api({ action: 'reminders_due' })).items.some((x) => x.id === idB), 'Rendez-vous déplacé : le rappel repart pour la nouvelle heure');

  // 6. Sans téléphone / rappels désactivés
  const idC = await create(page, { name: 'M. Petit', phone: '', date: ymd(tmr), time: '10:00' });
  ok(/Pas de numéro de mobile/.test(await page.textContent('#rappels')), 'Client sans numéro : signalé, pas d\'envoi');
  await page.goto(BASE + '/admin/view.php?id=' + idA);
  await Promise.all([page.waitForNavigation(), page.click('#rappels button[value=reminders_off]')]);
  ok(/Rappels désactivés pour ce client/.test(await page.textContent('#rappels')), '« Pas de rappel pour ce client » fonctionne');
  await Promise.all([page.waitForNavigation(), page.click('#rappels button[value=reminders_on]')]);

  // 7. API de l'app : rappels à venir (notifications)
  const up = await api({ action: 'reminders' });
  ok(up.items.some((x) => x.id === idA && x.rule === 'r1' && x.label === 'La veille à 18h00'), 'API app (reminders) : rappels à venir pour programmer les notifications');
  ok(!up.items.some((x) => x.id === idC), 'Client sans numéro exclu des notifications');

  await page.goto(BASE + '/admin/view.php?id=' + idA);
  await page.locator('#rappels').screenshot({ path: OUT + '/v3-03-fiche-rappels.png' });
  ok(errors.length === 0, 'Erreurs JavaScript : ' + (errors.length ? errors.join(' | ') : 'aucune'));
  await browser.close();
})().catch((e) => { console.log('❌ ' + e.message); process.exit(1); });
