// Nouveautés v2 : créneau d'arrivée, nom/e-mail facultatifs, zone masquée en mètres (+ migration v1 → v2)
const { chromium } = require('/home/claude/node_modules/playwright-core');
const { execSync } = require('child_process');
const BASE = 'http://127.0.0.1:8088';
const OUT = '/home/claude/suivi-test/shots';
const sql = (q) => execSync('php /home/claude/suivi-test/sql.php ' + JSON.stringify(q)).toString().trim();
const ok = (c, m) => console.log((c ? '✅ ' : '❌ ') + m);
const errors = [];

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome',
    args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });

  const before = sql("SELECT v FROM settings WHERE k='schema'");
  await page.goto(BASE + '/admin/login.php');
  ok(before === '1' && +sql("SELECT v FROM settings WHERE k='schema'") >= 2, 'Base v1 existante migrée en v2 à la première visite (' + sql('SELECT count(*) FROM interventions') + ' intervention(s) conservée(s))');
  await page.fill('input[name=password]', 'MotDePasseTest123');
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);

  // 1. Intervention SANS nom ni e-mail, créneau 14h00 → +30 min
  await page.goto(BASE + '/admin/edit.php');
  await page.fill('input[name=address]', '2 Avenue Thiers 77000 Melun');
  await page.evaluate(() => { document.querySelector('[name=lat]').value = '48.5326'; document.querySelector('[name=lon]').value = '2.6560'; document.querySelector('[name=ac_ok]').value = '1'; });
  await page.fill('input[name=time]', '14:00');
  await page.click('[data-slot-len="30"]');
  ok(await page.inputValue('input[name=time_end]') === '14:30', 'Bouton « +30 min » : fin du créneau = 14:30');
  await page.fill('input[name=time]', '15:00'); await page.dispatchEvent('input[name=time]', 'change');
  ok(await page.inputValue('input[name=time_end]') === '15:30', 'Décaler le début décale la fin (15:00 → 15:30)');
  await page.fill('input[name=time]', '14:00'); await page.dispatchEvent('input[name=time]', 'change');
  await page.locator('[data-slot]').screenshot({ path: OUT + '/v2-01-creneau-formulaire.png' });
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);
  const url = page.url();
  ok(/view\.php\?id=\d+/.test(url), 'Création acceptée sans nom ni e-mail');
  const id = url.match(/id=(\d+)/)[1];
  const h1 = await page.textContent('h1');
  ok(h1.includes('Client à Melun'), 'Titre automatique : « ' + h1.trim().replace(/\s+/g, ' ') + ' »');
  const confirm = await page.inputValue('[data-msg=confirm] textarea');
  ok(confirm.startsWith('Bonjour,') && confirm.includes('entre 14h00 et 14h30'), 'Message de confirmation : « ' + confirm.split('\n')[2].slice(0, 95) + '… »');
  const thanks = await page.inputValue('[data-msg=thanks] textarea');
  ok(thanks.startsWith('Merci pour votre confiance'), 'Message de remerciement sans nom correct');
  ok((await page.textContent('.kv')).includes('entre 14h00 et 14h30'), 'Fiche admin : « entre 14h00 et 14h30 »');
  await page.screenshot({ path: OUT + '/v2-02-fiche-sans-nom.png' });

  // 2. Validation : fin avant début refusée
  await page.goto(BASE + '/admin/edit.php?id=' + id);
  await page.fill('input[name=time_end]', '13:00');
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);
  ok((await page.textContent('body')).includes('La fin du créneau doit être après le début'), 'Créneau incohérent refusé avec un message clair');

  // 3. Page client : créneau affiché
  const token = sql('SELECT token FROM interventions WHERE id=' + id);
  const client = await ctx.newPage();
  client.on('pageerror', (e) => errors.push('client: ' + e.message));
  await client.goto(BASE + '/s/' + token);
  await client.waitForFunction(() => document.getElementById('heroBig').textContent.trim() !== '');
  const big = (await client.textContent('#heroBig')).trim(), title = (await client.textContent('#heroTitle')).trim();
  ok(big === '14h00 et 14h30' && title.endsWith('entre'), 'Page client : « ' + title + ' ' + big + ' »');
  const ov = await client.evaluate(() => { const b = document.getElementById('heroBig'); return b.scrollWidth <= b.parentElement.clientWidth; });
  ok(ov, 'Le créneau tient sur la largeur d\'un iPhone (390 px)');
  ok((await client.textContent('.c-card')).includes('Créneau d\'arrivée'), 'Carte « Créneau d\'arrivée » affichée');
  await client.screenshot({ path: OUT + '/v2-03-client-creneau.png' });

  // 4. Heure précise (sans fin) : comportement inchangé
  await page.goto(BASE + '/admin/edit.php?id=' + id);
  await page.click('[data-slot-len="0"]');
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);
  ok((await page.textContent('.kv')).includes('vers 14h00'), 'Bouton « Heure précise » : retour à « vers 14h00 »');

  // 5. Zone masquée personnalisée en mètres
  await page.goto(BASE + '/admin/settings.php');
  await page.fill('input[name=privacy_m]', '1234');
  await page.locator('[data-range]').screenshot({ path: OUT + '/v2-04-zone-masquee.png' });
  ok((await page.textContent('[data-range-out]')).trim() === '1,234 km', 'Affichage en direct : ' + (await page.textContent('[data-range-out]')).trim());
  await Promise.all([page.waitForNavigation(), page.locator('[data-range]').locator('xpath=ancestor::form').locator('button[type=submit]').click()]);
  ok(sql("SELECT v FROM settings WHERE k='privacy_m'") === '1234', 'Rayon enregistré : 1234 m');
  ok(await page.inputValue('input[name=privacy_m]') === '1234', 'Rayon réaffiché après enregistrement');
  // effet réel : position à 1,1 km du domicile → masquée ; à 1,4 km → visible
  const r = execSync(`php -r '
    require "/home/claude/suivi-test/www/inc/bootstrap.php"; require_once "/home/claude/suivi-test/www/inc/eta.php";
    $iv = get_iv(${id}); $iv["status"] = "enroute"; $iv["pos_ts"] = time(); $iv["pos_lon"] = 2.904;
    $iv["pos_lat"] = 48.387 + 1100/111195; $a = public_state($iv)["hidden"] ? "masquée" : "visible";
    $iv["pos_lat"] = 48.387 + 1400/111195; $b = public_state($iv)["hidden"] ? "masquée" : "visible";
    echo "$a|$b";'`).toString();
  ok(r === 'masquée|visible', 'Position à 1,1 km : ' + r.split('|')[0] + ' · à 1,4 km : ' + r.split('|')[1]);
  await page.evaluate(() => { document.querySelector('input[name=privacy_m]').value = '99999'; });
  await Promise.all([page.waitForNavigation(), page.evaluate(() => document.querySelector('input[name=privacy_m]').form.submit())]);
  ok(sql("SELECT v FROM settings WHERE k='privacy_m'") === '20000', 'Valeur excessive plafonnée à 20 000 m');

  ok(errors.length === 0, 'Erreurs navigateur : ' + (errors.length ? errors.join(' | ') : 'aucune'));
  await browser.close();
})().catch((e) => { console.log('❌ ' + e.message); process.exit(1); });
