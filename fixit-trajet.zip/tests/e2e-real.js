// Test de bout en bout avec les VRAIS services (carte OpenFreeMap, itinéraire OSRM, adresses IGN).
// Lancé par GitHub Actions : installation → intervention → trajet simulé sur la vraie route → page client → arrivée.
const { chromium } = require('playwright');
const { execSync } = require('child_process');
const fs = require('fs');
const BASE = 'http://127.0.0.1:8088';
const OUT = process.env.OUT || 'results';
fs.mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = [];
const say = (...a) => { const l = a.join(' '); console.log(l); log.push(l); };
const errors = [];
const sql = (q) => execSync('php tests/sql.php ' + JSON.stringify(q)).toString().trim();
const IPHONE = {
  viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true,
  userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1',
  locale: 'fr-FR', timezoneId: 'Europe/Paris',
};
function watch(page, name) {
  page.on('console', (m) => { if (m.type() === 'error' || /Content Security Policy/i.test(m.text())) errors.push(name + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push(name + ' (exception): ' + e.message));
  page.on('requestfailed', (r) => errors.push(name + ' (requête échouée): ' + r.url().slice(0, 120) + ' ' + (r.failure() || {}).errorText));
}
async function mapLoaded(page) {
  // attend que MapLibre ait fini de charger les tuiles
  await page.waitForFunction(() => {
    const c = document.querySelector('.maplibregl-canvas');
    return c && c.width > 0;
  }, null, { timeout: 20000 }).catch(() => {});
  await sleep(4000);
}

(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const admin = await browser.newContext({ ...IPHONE, permissions: ['geolocation'], geolocation: { latitude: 48.387, longitude: 2.904 } });
  const page = await admin.newPage();
  watch(page, 'admin');

  // 1. Installation avec autocomplétion réelle de l'adresse du domicile
  await page.goto(BASE + '/install.php');
  await page.fill('input[name=password]', 'MotDePasseTest123');
  await page.fill('input[name=password2]', 'MotDePasseTest123');
  await page.type('input[name=home]', 'mairie la grande paroisse', { delay: 40 });
  await page.waitForSelector('.ac-list button', { timeout: 15000 });
  await page.screenshot({ path: OUT + '/01-install-autocompletion.png' });
  await page.click('.ac-list button');
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);
  const home = sql("SELECT v FROM settings WHERE k IN ('home_lat','home_lon') ORDER BY k").split('\n').map(Number);
  const dHome = Math.hypot((home[0] - 48.387) * 111, (home[1] - 2.904) * 74);
  say('Domicile géocodé :', home.join(', '), dHome < 5 ? '✅ La Grande-Paroisse' : '❌ à ' + dHome.toFixed(0) + ' km de La Grande-Paroisse');
  await admin.setGeolocation({ latitude: home[0], longitude: home[1], accuracy: 10 });

  // 2. Intervention avec adresse réelle
  await page.goto(BASE + '/admin/edit.php');
  await page.fill('input[name=client_name]', 'Mme Martin');
  await page.fill('input[name=client_phone]', '06 12 34 56 78');
  await page.fill('input[name=client_email]', 'martin@example.fr');
  await page.type('input[name=address]', '2 avenue thiers melun', { delay: 40 });
  await page.waitForSelector('.ac-list button', { timeout: 15000 });
  await page.click('.ac-list button');
  const d = new Date(Date.now() + 3600e3);
  await page.fill('input[name=date]', d.toISOString().slice(0, 10));
  await page.fill('input[name=time]', '15:00');
  await page.check('input[value=lent]', { force: true });
  await Promise.all([page.waitForNavigation(), page.click('button[type=submit]')]);
  const link = await page.inputValue('#clientLink');
  const ivId = new URL(page.url()).searchParams.get('id');
  say('Adresse client :', sql('SELECT address, lat, lon FROM interventions WHERE id=' + ivId));

  // 3. Page client avant départ (vraie carte)
  const client = await browser.newContext(IPHONE);
  const cpage = await client.newPage();
  watch(cpage, 'client');
  await cpage.goto(link.replace(/^https?:\/\/[^/]+/, BASE));
  await mapLoaded(cpage);
  await cpage.screenshot({ path: OUT + '/02-client-avant-depart.png' });

  // 4. Départ (mode trajet web) puis conduite le long de la VRAIE route OSRM
  await page.goto(BASE + '/admin/drive.php?id=' + ivId);
  await mapLoaded(page);
  await page.click('#btnStart');
  await sleep(5000);
  const st0 = sql('SELECT status, route_provider, round(route_dist_m/1000,1), round(route_raw_s/60), eta_at - strftime(\'%s\',\'now\') FROM interventions WHERE id=' + ivId);
  say('Après départ (statut|fournisseur|km|min brutes|s restantes) :', st0);
  const route = JSON.parse(sql('SELECT route_json FROM interventions WHERE id=' + ivId) || '[]');
  say('Points de l\'itinéraire réel :', route.length);
  const steps = 26;
  for (let i = 1; i <= steps; i++) {
    const p = route[Math.floor((route.length - 1) * (i / steps) * 0.7)];
    await admin.setGeolocation({ latitude: p[1], longitude: p[0], accuracy: 8 });
    await sleep(1500);
    if (i === 3) await cpage.screenshot({ path: OUT + '/03-client-zone-masquee.png' });
  }
  await sleep(6000);
  await mapLoaded(page);
  await page.screenshot({ path: OUT + '/04-iphone-mode-trajet.png' });
  await sleep(4000);
  await cpage.screenshot({ path: OUT + '/05-client-en-route.png' });
  await cpage.screenshot({ path: OUT + '/06-client-en-route-page.png', fullPage: true });
  say('Page client :', (await cpage.textContent('#hero')).replace(/\s+/g, ' ').trim());
  say('Voiture FixIT sur la carte :', await cpage.locator('.car-marker').count());

  const desk = await browser.newContext({ viewport: { width: 1366, height: 900 }, locale: 'fr-FR', timezoneId: 'Europe/Paris' });
  const dp = await desk.newPage();
  watch(dp, 'client-pc');
  await dp.goto(link.replace(/^https?:\/\/[^/]+/, BASE));
  await mapLoaded(dp);
  await dp.screenshot({ path: OUT + '/07-client-ordinateur.png' });

  // 5. Fiche admin + test des services depuis les Réglages
  const vp = await admin.newPage();
  watch(vp, 'fiche');
  await vp.goto(BASE + '/admin/view.php?id=' + ivId);
  await sleep(3000);
  await vp.screenshot({ path: OUT + '/08-fiche-intervention.png', fullPage: true });
  await vp.goto(BASE + '/admin/settings.php');
  await Promise.all([vp.waitForNavigation(), vp.click('form:has(input[value=test]) button')]);
  await vp.screenshot({ path: OUT + '/09-reglages-test-services.png', fullPage: true });
  await vp.close();

  // 6. Arrivée automatique
  const dest = sql('SELECT lat, lon FROM interventions WHERE id=' + ivId).split('|').map(Number);
  await admin.setGeolocation({ latitude: dest[0] + 0.0004, longitude: dest[1], accuracy: 6 });
  await sleep(5000);
  await admin.setGeolocation({ latitude: dest[0] + 0.0002, longitude: dest[1], accuracy: 6 });
  await sleep(6000);
  say('Statut à l\'adresse du client :', sql('SELECT status FROM interventions WHERE id=' + ivId));
  await cpage.reload();
  await sleep(3000);
  await cpage.screenshot({ path: OUT + '/10-client-arrive.png' });

  // erreurs : on ignore les favicon et les annulations de tuiles normales lors des zooms
  const real = errors.filter((e) => !/favicon|net::ERR_ABORTED/.test(e));
  say('Erreurs navigateur :', real.length ? '\n  ' + real.join('\n  ') : 'aucune');
  fs.writeFileSync(OUT + '/e2e.txt', log.join('\n') + '\n');
  await browser.close();
  process.exit(real.length ? 2 : 0);
})().catch((e) => { console.error('ÉCHEC', e); fs.writeFileSync(OUT + '/e2e.txt', log.join('\n') + '\nÉCHEC ' + e.stack + '\n'); process.exit(1); });
