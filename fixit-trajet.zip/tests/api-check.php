<?php
// Vérifie les VRAIS services gratuits utilisés par FixIT Suivi (exécuté sur GitHub, accès Internet complet).
declare(strict_types=1);
$_SERVER['HTTP_HOST'] = '127.0.0.1:8088';
require __DIR__ . '/../site/inc/bootstrap.php';
$ok = true;
function line(string $label, bool $pass, string $detail): void { global $ok; $ok = $ok && $pass; printf("%s %-42s %s\n", $pass ? '✅' : '❌', $label, $detail); }

$t = microtime(true);
$home = geocode_search('Mairie 77130 La Grande-Paroisse', 1);
line('Géocodage IGN (La Grande-Paroisse)', (bool)$home, $home ? $home[0]['label'] . sprintf(' (%.4f, %.4f) %.2fs', $home[0]['lat'], $home[0]['lon'], microtime(true) - $t) : 'échec');
$t = microtime(true);
$dest = geocode_search('2 avenue Thiers 77000 Melun', 1);
line('Géocodage IGN (Melun)', (bool)$dest, $dest ? $dest[0]['label'] . sprintf(' (%.4f, %.4f) %.2fs', $dest[0]['lat'], $dest[0]['lon'], microtime(true) - $t) : 'échec');
// Saisie floue (comme au clavier) : la priorité géographique doit ramener la bonne commune
$t = microtime(true);
$fz = geocode_search('mairie la grande paroisse', 3);
$okfz = $fz && haversine($fz[0]['lat'], $fz[0]['lon'], 48.387, 2.904) < 5000;
line('Saisie floue « mairie la grande paroisse »', $okfz, $fz ? $fz[0]['label'] . sprintf(' (%.4f, %.4f) %.2fs', $fz[0]['lat'], $fz[0]['lon'], microtime(true) - $t) : 'échec');
[$a, $b] = [$home[0] ?? ['lat' => 48.387, 'lon' => 2.904], $dest[0] ?? ['lat' => 48.539, 'lon' => 2.660]];

foreach ([OSRM_PRIMARY => 'Itinéraire OSRM principal', OSRM_FALLBACK => 'Itinéraire OSRM FOSSGIS (secours)'] as $url => $label) {
    $t = microtime(true);
    $r = route_osrm($url, $a['lat'], $a['lon'], $b['lat'], $b['lon']);
    line($label, (bool)$r, $r ? sprintf('%.1f km, %d min sans trafic, %d points, %.2fs', $r['dist_m'] / 1000, round($r['raw_s'] / 60), count($r['coords']), microtime(true) - $t) : 'échec');
}
$r = compute_route($a['lat'], $a['lon'], $b['lat'], $b['lon']);
$prior = learned_factor(false) * tod_factor(strtotime('next thursday 08:00'));
if ($r) {
    echo sprintf("   → Heure annoncée un jeudi 8h00 (pointe) : %d min · un dimanche 15h : %d min\n",
        round($r['raw_s'] * $prior / 60) + 2, round($r['raw_s'] * learned_factor(false) * tod_factor(strtotime('next sunday 15:00')) / 60) + 2);
}

// Carte OpenFreeMap : style + vérifie que toutes les ressources restent sur le domaine autorisé par la CSP
$t = microtime(true);
$style = http_get_json('https://tiles.openfreemap.org/styles/positron');
line('Style de carte OpenFreeMap (positron)', (bool)$style, $style ? sprintf('%d calques, %.2fs', count($style['layers'] ?? []), microtime(true) - $t) : 'échec');
if ($style) {
    $hosts = [];
    foreach (($style['sources'] ?? []) as $s) { if (!empty($s['url'])) $hosts[] = parse_url($s['url'], PHP_URL_HOST); foreach ($s['tiles'] ?? [] as $u) $hosts[] = parse_url($u, PHP_URL_HOST); }
    foreach (['glyphs', 'sprite'] as $k) { $v = $style[$k] ?? null; foreach ((array)$v as $u) { $u = is_array($u) ? ($u['url'] ?? '') : $u; if ($u) $hosts[] = parse_url(str_replace(['{fontstack}', '{range}'], ['x', 'y'], $u), PHP_URL_HOST); } }
    $hosts = array_values(array_unique(array_filter($hosts)));
    line('Ressources de carte autorisées par la CSP', $hosts === ['tiles.openfreemap.org'], implode(', ', $hosts));
    foreach ($style['sources'] ?? [] as $s) {
        if (!empty($s['url'])) { $tj = http_get_json($s['url']); line('Tuiles vectorielles (TileJSON)', !empty($tj['tiles']), $tj['tiles'][0] ?? 'échec'); break; }
    }
}

// CORS de l'IGN (autocomplétion appelée directement depuis le navigateur)
$ch = curl_init('https://data.geopf.fr/geocodage/search?q=melun&limit=1');
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => true, CURLOPT_NOBODY => false, CURLOPT_HTTPHEADER => ['Origin: https://suivi.fixit-service.fr'], CURLOPT_TIMEOUT => 10]);
$resp = (string)curl_exec($ch);
preg_match('/^access-control-allow-origin:\s*(.+)$/mi', $resp, $m);
line('CORS IGN (appel direct navigateur)', isset($m[1]), trim($m[1] ?? 'absent → le relais PHP prend le relais'));

echo $ok ? "\nRÉSULTAT : tous les services répondent.\n" : "\nRÉSULTAT : au moins un service a échoué.\n";
